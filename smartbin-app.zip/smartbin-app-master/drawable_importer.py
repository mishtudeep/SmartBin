import os

name = raw_input("Enter External path: ")
external_path = '~/Downloads/'
external_file = external_path + name + '.zip'
internal_path = './app/src/main/res/'

os.system('unzip ' + external_file)

external_path = external_path + 'res/'

exts = ['drawable-hdpi', 'drawable-mdpi', 'drawable-xhdpi', 'drawable-xxhdpi', 'drawable-xxxhdpi']
#exts = ['mipmap-hdpi', 'mipmap-mdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi']

for ext in exts:
    command = 'mv ./res/' + ext + '/* ' + internal_path + ext + '/'
    os.system(command)

os.system('rm -rf res')
