package com.android.smartbin.app.repository

import android.location.Location
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.android.smartbin.app.MainApplication
import com.android.smartbin.app.api.ApiResponse
import com.android.smartbin.app.api.ApiService
import com.android.smartbin.app.models.*
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.viewmodel.LoadingStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.io.IOException

class ApiRepository(private val apiService: ApiService) : MockRepository() {

    /*
    * generic section for all the api services
    * */
    private var loadingStatusLD: MutableLiveData<LoadingStatus?>? = null

    fun setStatusLD(loadingStatusLD: MutableLiveData<LoadingStatus?>) {
        this.loadingStatusLD = loadingStatusLD
    }

    private suspend fun <T : Any?> safeApiCall(
        call: suspend () -> Response<ApiResponse<T?>>,
        errorMessage: String,
        showLoader: Boolean = true
    ): T? {
        val apiResult = safeApiResult(call, errorMessage, showLoader)
        if (showLoader) loadingStatusLD?.postValue(LoadingStatus.LOADING_ENDED)
        when (apiResult) {
            is ApiResult.Success -> return apiResult.data
            is ApiResult.Error -> {
                withContext(Dispatchers.Main) {
                    Toast.makeText(MainApplication.instance, errorMessage, Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
        return null
    }

    private suspend fun <T> safeApiResult(
        call: suspend () -> Response<ApiResponse<T?>>,
        errorMessage: String,
        showLoader: Boolean = true
    ): ApiResult<T?> {
        if (showLoader) loadingStatusLD?.postValue(LoadingStatus.LOADING_STARTED)
        val response = call.invoke()
        if (response.isSuccessful) return ApiResult.Success(response.body()?.data)
        return ApiResult.Error(IOException(errorMessage))
    }


    /*
    * login
    * */
    suspend fun login(email: String, password: String): User? {
        return when {
            isMock -> getMockLogin()
            else -> safeApiCall(
                call = { apiService.loginAsync(email, password) },
                errorMessage = "Login is not successful"
            )
        }
    }

    /*
    * forget password
    * */
    suspend fun forgetPassword(email: String): Boolean {
        return when {
            isMock -> true
            else -> {
//                val result = safeApiCall(
//                    call = { apiService.forgetPasswordAsync(email) },
//                    errorMessage = "Password reset is unsuccessful"
//                )
//                result != null
                true
            }
        }
    }

    /*
    * OTP submission (forget password)
    * */
    suspend fun submitOTP(email: String, otp: String, password: String): Boolean {
        return when {
            isMock -> true
            else -> {
                val result = safeApiCall(
                    call = { apiService.submitOtpAsync(email, otp, password) },
                    errorMessage = "Password reset was not successful"
                )
                result != null
            }
        }
    }

    /*
    * registration
    * */
    suspend fun register(name: String, email: String, password: String): User? {
        return when {
            isMock -> getMockLogin()
            else -> {
                safeApiCall(
                    call = {
                        apiService.registerAsync(
                            name = name,
                            email = email,
                            password = password
                        )
                    },
                    errorMessage = "Email address is already registered"
                )
            }
        }
    }


    /*
    * verifyOtp (registration)
    * */
    suspend fun verifyOtp(otp: String): Boolean {
        return when {
            isMock -> true
            else -> {
                PreferenceUtil.instance.getUser()?.let {
                    val result = safeApiCall(
                        call = { apiService.verifyOtpAsync(it.userId, otp) },
                        errorMessage = "OTP could not be verified"
                    )
                    result != null
                } ?: false
            }
        }
    }

    /*
    * fetch dustbin list based on location
    * */
    suspend fun fetchDustBinList(location: Location?): List<DustBin>? {
        if (location == null) return null
        return when {
            isMock -> getMockDustBinList()
            else -> PreferenceUtil.instance.getUser()?.let {
                safeApiCall(
                    call = {
                        apiService.getDustBinListAsync(
                            userId = it.userId,
                            clientId = it.client.clientId,
                            lat = location.latitude,
                            lng = location.longitude
                        )
                    },
                    errorMessage = "Dustbins could not be found"
                )
            }
        }
    }

    /*
    * get dump history
    * */
    suspend fun getDumpHistory(): List<DumpItem>? {
        return when {
            isMock -> getMockHistoryList()
            else -> PreferenceUtil.instance.getUser()?.let {
                safeApiCall(
                    call = {
                        apiService.getHistoryListAsync(
                            userId = it.userId
                        )
                    },
                    errorMessage = "History could not be found"
                )
            }
        }
    }

    /*
    * get wallet transaction
    * */
    suspend fun getWalletTransactions(): List<WalletTransaction>? {
        return when {
            isMock -> getMockTransactionList()
            else -> PreferenceUtil.instance.getUser()?.let {
                safeApiCall(
                    call = {
                        apiService.getWalletTransactionsAsync(
                            userId = it.userId
                        )
                    },
                    errorMessage = "Wallet transactions could not be found"
                )
            }
        }
    }

    /*
    * start dump
    * */
    suspend fun startDumping(binId: String): String? {
        return when {
            isMock -> "1"
            else -> PreferenceUtil.instance.getUser()?.let {
                safeApiCall(
                    call = {
                        apiService.startDumpingAsync(
                            userId = it.userId,
                            binId = binId
                        )
                    },
                    errorMessage = "Dumping could not be started"
                )
            }
        }
    }

    suspend fun stopDumping(dumpId: String?) {
        when {
            isMock -> {

            }
            else -> safeApiCall(
                call = {
                    apiService.stopDumpingAsync(
                        dumpId = dumpId ?: ""
                    )
                },
                errorMessage = "Dumping stop error"
            )
        }
    }

    suspend fun getDumpStatus(dumpId: String): DumpItem? {
        return when {
            isMock -> getMockHistoryList()[0]
            else -> {
                safeApiCall(
                    call = {
                        apiService.getDumpAsync(
                            dumpId = dumpId
                        )
                    },
                    errorMessage = "",
                    showLoader = false
                )
            }
        }
    }
    /*
    * add balance
    * */
    suspend fun addBalanceAsync(amount: String) : User? {
        return  when {
            isMock -> getMockLogin()
            else -> {
                PreferenceUtil.instance.getUser()?.let {
                    safeApiCall(
                        call = {
                            apiService.addBalanceAsync(
                                userId = it.userId,
                                amount = amount
                            )
                        },
                        errorMessage = "Balance can not be added"
                    )
                }
            }
        }
    }
}
