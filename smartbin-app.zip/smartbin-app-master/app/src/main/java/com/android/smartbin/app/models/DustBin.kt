package com.android.smartbin.app.models

import android.location.Location
import android.location.LocationManager
import com.google.android.gms.maps.model.LatLng
import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.lang.Exception

data class DustBin(
    @SerializedName("bin_id") val dustbinId: String = "",
    @SerializedName("height") val height: String = "",
    @SerializedName("width") val width: String = "",
    @SerializedName("length") val length: String = "",
    @SerializedName("capacity") val capacity: String = "",
    @SerializedName("house_name") val houseName: String = "",
    @SerializedName("address_line_1") val addressLine1: String = "",
    @SerializedName("address_line_2") val addressLine2: String = "",
    @SerializedName("latitude") val latitude: String = "",
    @SerializedName("longitude") val longitude: String = "",
    @SerializedName("updated_on") val updated_on: String = ""
) : Serializable {
    fun toLatLng(): LatLng? {
        try {
            return LatLng(latitude.toDouble(), longitude.toDouble())
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return null
    }

    fun toLocation(): Location {
        return Location(LocationManager.GPS_PROVIDER).also {
            it.latitude = this.latitude.toDouble()
            it.longitude = this.longitude.toDouble()
        }
    }
}