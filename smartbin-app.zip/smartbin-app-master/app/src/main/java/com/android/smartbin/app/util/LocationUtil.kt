package com.android.smartbin.app.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentSender
import android.location.Location
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.android.smartbin.app.MainActivity
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.tasks.Task

class LocationUtil(private val activityContext: AppCompatActivity) : LocationCallback() {
    companion object {
        const val REQUEST_CHECK_SETTINGS = 40440
    }

    private val locationRequest by lazy {
        LocationRequest.create().also {
            it.interval = 1000 * 10
            it.fastestInterval = 1000 * 5
            it.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
    }

    private val fusedLocationClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(activityContext)
    }

    private val locationLD = MutableLiveData<Location?>().default(null)

    fun getLocationLD() = locationLD

    fun onCreate() {
        // check for permission
        // check for settings
        // if all okay, start location updates
        (activityContext as MainActivity).let {
            it.permissionManager()
                .requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)) { granted ->
                    if (granted) {
                        // check for settings
                        val builder =
                            LocationSettingsRequest.Builder().addLocationRequest(locationRequest)
                        val client: SettingsClient =
                            LocationServices.getSettingsClient(activityContext)
                        val task: Task<LocationSettingsResponse> =
                            client.checkLocationSettings(builder.build())
                        task.addOnSuccessListener {
                            // All location settings are satisfied. The client can initialize
                            // location requests here.
                            // ...
                            initiateLocationRequest()
                        }
                        task.addOnFailureListener { exception ->
                            if (exception is ResolvableApiException) {
                                // Location settings are not satisfied, but this can be fixed
                                // by showing the user a dialog.
                                try {
                                    // Show the dialog by calling startResolutionForResult(),
                                    // and check the result in onActivityResult().
                                    exception.startResolutionForResult(
                                        activityContext,
                                        REQUEST_CHECK_SETTINGS
                                    )
                                } catch (sendEx: IntentSender.SendIntentException) {
                                    // Ignore the error.
                                }
                            }
                        }
                    }
                }
        }
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            onCreate()
            return true
        }
        return false
    }

    @SuppressLint("MissingPermission")
    private fun initiateLocationRequest() {
        fusedLocationClient.requestLocationUpdates(locationRequest, this, Looper.myLooper())
    }

    override fun onLocationResult(locationResult: LocationResult?) {
        locationResult?.lastLocation?.let {
            locationLD.postValue(it)
        }
    }
}