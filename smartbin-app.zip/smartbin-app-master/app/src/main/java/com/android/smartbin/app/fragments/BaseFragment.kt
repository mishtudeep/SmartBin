package com.android.smartbin.app.fragments

import android.location.Location
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.android.smartbin.app.MainActivity

open class BaseFragment : Fragment() {
    internal var location: Location? = null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainActivity).locationUtil().getLocationLD().observe(viewLifecycleOwner, Observer {
            location = it
        })
    }

    override fun onResume() {
        super.onResume()
        (activity as? MainActivity)?.update(isAppBarRequired(), isDrawerLocked())
    }

    open fun isDrawerLocked(): Boolean = false

    open fun isAppBarRequired(): Boolean = true

    fun replaceFragment(containerId: Int, fragment: BaseFragment) {
        childFragmentManager.beginTransaction().replace(containerId, fragment).commit()
    }

    fun navigate(id: Int) {
        view?.let {
            try {
                (activity as MainActivity).let { activity ->
                    activity.hideKeyboard()
                    activity.navigate(id)
                }
            } catch (e: IllegalArgumentException) {
                e.printStackTrace()
            }
        }
    }

    fun navigateWithArgument(id: Int, argument: Bundle?) {
        view?.let {
            try {
                (activity as MainActivity).let { activity ->
                    activity.hideKeyboard()
                    activity.navigate(id, argument)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun navigateUp() {
        view?.let {
            try {
                (activity as MainActivity).let { activity ->
                    activity.hideKeyboard()
                    activity.onSupportNavigateUp()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}