package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.smartbin.app.R
import com.android.smartbin.app.adapter.HistoryAdapter
import com.android.smartbin.app.databinding.FragmentHistoryBinding
import com.android.smartbin.app.models.DumpItem
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_history.*

class HistoryFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentHistoryBinding
    private val userVM: UserViewModel by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }
    private var adapter: HistoryAdapter? = null
    private var items: MutableList<DumpItem> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_history, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (adapter == null) {
            adapter = HistoryAdapter(activity!!, items)
            historyRecycler.layoutManager = LinearLayoutManager(activity!!)
            historyRecycler.adapter = adapter
        }

        userVM.getDumpHistoryLD().observe(viewLifecycleOwner, Observer {
            historyRefresh.isRefreshing = false
            if (it != null) {
                adapter?.updateList(it)
            }
        })

        historyRefresh.setOnRefreshListener {
            userVM.fetDumpHistoryList()
        }

        userVM.fetDumpHistoryList()
    }
}