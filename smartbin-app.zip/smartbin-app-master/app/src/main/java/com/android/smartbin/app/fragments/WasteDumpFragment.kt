package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentWasteDumpBinding
import com.android.smartbin.app.models.DustBin
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_waste_dump.*

class WasteDumpFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentWasteDumpBinding
    private var dustbin: DustBin? = null

    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dustbin = arguments?.getSerializable("dustbin") as DustBin?
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_waste_dump, container, false);
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.dustbin = this.dustbin
        userVM.getDumpingTimeLD().observe(viewLifecycleOwner, Observer {
            rootBinding.timeString = it
        })

        userVM.completeBtnTextLD().observe(viewLifecycleOwner, Observer {
            rootBinding.completeBtn.text = it
        })

        completeBtn.setOnClickListener {
            if (userVM.isDumping()) {
                onDumpingCompleted()
            } else {
                userVM.startDumpingTimer(dustbin?.dustbinId ?: "") { onDumpingCompleted() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        userVM.resetDumpingTimeLD()
    }

    private fun onDumpingCompleted() {
        userVM.stopDumpingTimer()
        navigate(R.id.action_wasteDumpFragment_to_dumpingCompletionFragment)
    }
}