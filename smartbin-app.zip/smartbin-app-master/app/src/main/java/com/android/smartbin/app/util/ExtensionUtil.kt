package com.android.smartbin.app.util

import android.location.Location
import android.widget.SeekBar
import android.widget.Toast
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.android.smartbin.app.MainApplication
import com.google.android.gms.maps.model.LatLng
import com.google.android.material.textfield.TextInputLayout
import org.joda.time.DateTimeZone
import org.joda.time.format.DateTimeFormat
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import org.joda.time.format.PeriodFormatterBuilder
import org.joda.time.format.PeriodFormatter
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import org.joda.time.Period


fun <T> MutableLiveData<T>.default(defaultVal: T) = apply { value = defaultVal }

fun <T> LiveData<T>.observeOnce(
    lifecycleOwner: LifecycleOwner,
    observer: Observer<T>,
    removeOnlyIfNonNull: Boolean = true
) {
    observe(lifecycleOwner, object : Observer<T> {
        override fun onChanged(value: T) {
            observer.onChanged(value)
            if (!removeOnlyIfNonNull) {
                removeObserver(this)
            } else if (removeOnlyIfNonNull && value != null) {
                removeObserver(this)
            }
        }
    })
}

fun <T> LiveData<T>.observeWithPredicate(
    lifecycleOwner: LifecycleOwner,
    observer: Observer<T>,
    predicate: (T?) -> Boolean
) {
    observe(lifecycleOwner, Observer<T> {
        val isValid = predicate.invoke(it)
        if (isValid) {
            observer.onChanged(it)
            removeObservers(lifecycleOwner)
        }
    })
}

fun <E> MutableList<E>.unique(interceptor: (E) -> String): MutableList<E> {
    val keyList = mutableListOf<String>()
    val itemList = mutableListOf<E>()
    this.forEach {
        val key = interceptor.invoke(it)
        if (key !in keyList) {
            keyList.add(key)
            itemList.add(it)
        }
    }
    return itemList
}

private var lastValid: String? = null
fun List<Pair<TextInputLayout, ValidityRule>>.addWatchers(validityCallback: (Boolean) -> Unit) {
    this.forEach {
        it.first.editText?.addTextChangedListener(InputValidityWatcher(it.second) { valid ->
            if (valid != null) {
                if (lastValid != valid) {
                    Toast.makeText(MainApplication.instance, valid, Toast.LENGTH_SHORT).show()
                    lastValid = valid
                }
                validityCallback(false)
            } else validityCallback.invoke(this.all { pair ->
                InputValidityWatcher.isValid(
                    pair.first.editText?.text.toString(),
                    pair.second
                ) == null
            })
        })
    }
}

fun Int.isEven(): Boolean {
    return this % 2 == 0
}

fun SeekBar.setOnSeekBarChangeListener(callback: (Int) -> Unit) {
    this.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) callback.invoke(progress)
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {

        }

        override fun onStopTrackingTouch(seekBar: SeekBar?) {

        }

    })
}

fun LatLng?.distanceTo(that: LatLng?): Int {
    if (this == null || that == null) return -1
    return distance(this.latitude, this.longitude, that.latitude, that.longitude).roundToInt()
}

private fun distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val theta = lon1 - lon2
    var dist =
        sin(deg2rad(lat1)) * sin(deg2rad(lat2)) + (cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * cos(
            deg2rad(theta)
        ))
    dist = acos(dist)
    dist = rad2deg(dist)
    dist *= 60.0 * 1.1515
    return dist
}

private fun deg2rad(deg: Double): Double {
    return deg * Math.PI / 180.0
}

private fun rad2deg(rad: Double): Double {
    return rad * 180.0 / Math.PI
}

fun Location?.toLatLng(): LatLng? {
    return this?.let {
        LatLng(it.latitude, it.longitude)
    }
}

fun Int.toDistanceString(): String? {
    return when {
        this == -1 -> null
        else -> this.toString()
    }
}

fun String.toLocalDateTime(): String {
    return DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").let {
        it.withZone(DateTimeZone.getDefault())
            .print(it.withZoneUTC().parseDateTime(this).toDateTime(DateTimeZone.getDefault()))
    }
}

fun String.toReadableTimeStamp(): String {
    return DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").let {
        it.withZone(DateTimeZone.getDefault())
            .print(it.withZoneUTC().parseDateTime(this).toDateTime(DateTimeZone.getDefault()))
    }
}

fun Int.toMinuteString(): String {
    val myFormat = PeriodFormatterBuilder()
        .printZeroAlways().minimumPrintedDigits(2).appendMinutes()
        .appendSeparator(":")
        .printZeroAlways().minimumPrintedDigits(2).appendSeconds()
        .toFormatter()
    val period = Period.seconds(this).normalizedStandard()
    return myFormat.print(period)
}