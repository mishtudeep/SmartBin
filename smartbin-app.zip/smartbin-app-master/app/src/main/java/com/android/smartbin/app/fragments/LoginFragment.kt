package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentLoginBinding
import com.android.smartbin.app.util.ValidityRule
import com.android.smartbin.app.util.addWatchers
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_login.*

class LoginFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentLoginBinding
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_login, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.isSubmitEnabled = false

        rootBinding.registerAnc.setOnClickListener {
            navigate(R.id.action_loginFragment_to_registrationFragment)
        }

        rootBinding.forgetPasswordAnc.setOnClickListener {
            navigate(R.id.action_loginFragment_to_forgetPasswordFragment)
        }

        rootBinding.loginBtn.setOnClickListener {
            processLogin()
        }

        listOf(
            phoneInputLayout to ValidityRule.EMAIL,
            passwordInputLayout to ValidityRule.PASSWORD
        ).addWatchers {
            rootBinding.isSubmitEnabled = it
        }
    }

    private fun processLogin() {
        userVM.login(phoneInput.text.toString(), passwordInput.text.toString()) {
            if (it) {
                navigate(R.id.action_loginFragment_to_dashboardNavigation)
            }
        }
    }

    override fun isDrawerLocked(): Boolean = true

    override fun isAppBarRequired(): Boolean = false
}