package com.android.smartbin.app.models

import com.android.smartbin.app.util.toReadableTimeStamp
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class WalletTransaction(
    @SerializedName("transaction_id") val transactionId: String,
    @SerializedName("currency") val currency: String,
    @SerializedName("amount") val amount: String,
    @SerializedName("type") val type: String,
    @SerializedName("updated_on") val updatedOn: String
) : Serializable {
    fun toReadableTimeStamp(): String {
        return updatedOn.toReadableTimeStamp()
    }
}