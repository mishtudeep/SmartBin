package com.android.smartbin.app.util

import android.text.Editable
import android.text.TextWatcher

class InputValidityWatcher(
    private val validityRule: ValidityRule, private val callback: (String?) -> Unit
) : TextWatcher {

    override fun afterTextChanged(s: Editable?) {
        callback(isValid(s.toString(), validityRule))
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        // nothing to do
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        // nothing to do
    }

    companion object {
        fun isValid(input: String, validityRule: ValidityRule): String? {
            return when (validityRule) {
                ValidityRule.PHONE -> {
                    when {
                        input.isEmpty() -> "Phone number can not be empty"
                        input.length != 10 -> "Phone number is not valid"
                        else -> null
                    }
                }
                ValidityRule.NAME -> {
                    when {
                        input.isEmpty() -> "Name can not be empty"
                        else -> null
                    }
                }
                ValidityRule.PASSWORD -> {
                    when {
                        input.isEmpty() -> "Password can not be empty"
                        input.length < 8 -> "Password must be at lease 8 characters"
                        else -> null
                    }
                }
                ValidityRule.OTP -> {
                    when {
                        input.isEmpty() -> "OTP can not be empty"
                        input.length != 6 -> "OTP must be 6 characters long"
                        else -> null
                    }
                }
                ValidityRule.EMAIL -> {
                    when {
                        input.isEmpty() -> "Email can not be empty"
                        else -> null
                    }
                }
            }
        }
    }
}

enum class ValidityRule {
    PHONE, PASSWORD, NAME, OTP, EMAIL
}