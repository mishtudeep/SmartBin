package com.android.smartbin.app.models

import com.google.gson.annotations.SerializedName

data class BinClient(
    @SerializedName("client_id") val clientId: String
)