package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.util.observeOnce
import com.android.smartbin.app.viewmodel.AppStateViewModel

class SplashFragment : BaseFragment() {
    private lateinit var appStateViewModel: AppStateViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_splash, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        appStateViewModel = ViewModelProviders.of(activity!!)[AppStateViewModel::class.java]

        appStateViewModel.getAppState().observeOnce(viewLifecycleOwner, Observer {
            if (it != null) {
                when (it) {
                    AppStateViewModel.AppState.TUTORIAL -> navigate(R.id.action_splashFragment_to_tutorialFragment)
                    AppStateViewModel.AppState.LOGIN -> navigate(R.id.action_splashFragment_to_loginFragment)
                    AppStateViewModel.AppState.VERIFICATION -> navigate(R.id.action_splashFragment_to_verificationFragment)
                    AppStateViewModel.AppState.REGISTER -> navigate(R.id.action_splashFragment_to_registrationFragment)
                    else -> navigate(R.id.action_splashFragment_to_dashboardNavigation)
                }
            }
        })

        appStateViewModel.onSplashShown()
    }

    override fun isDrawerLocked(): Boolean = true
    override fun isAppBarRequired(): Boolean = false
}