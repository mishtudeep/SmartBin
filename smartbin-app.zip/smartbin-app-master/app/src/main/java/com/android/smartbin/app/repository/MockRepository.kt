package com.android.smartbin.app.repository

import com.android.smartbin.app.BuildConfig
import com.android.smartbin.app.models.*

open class MockRepository {
    val isMock: Boolean = BuildConfig.IS_MOCK

    fun getMockLogin(): User {
        return User(
            "1",
            "Dummy",
            "User",
            "Dummy user address 1",
            "Dummy user address 2",
            "dummy_user@binbillings.com",
            "9876543210",
            "pic.jpg",
            "code1",
            "20",
            "€",
            "2019-09-18 21:17:37",
            BinClient(
                "1"
            )
        )
    }

    fun getMockDustBinList(): List<DustBin> {
        return emptyList()
    }

    fun getMockHistoryList(): List<DumpItem> {
        val list: MutableList<DumpItem> = mutableListOf()
        for (index in 1..20) {
            list.add(
                DumpItem(
                    index.toString(),
                    DustBin(
                        dustbinId = "1",
                        addressLine1 = "Some dummy address"
                    ),
                    "48",
                    "40",
                    "€",
                    "2019-09-09 09:09:09"
                )
            )
        }
        return list
    }

    fun getMockTransactionList(): List<WalletTransaction> {
        val list: MutableList<WalletTransaction> = mutableListOf()
        for (index in 1..20) {
            list.add(
                WalletTransaction(
                    index.toString(),
                    "€",
                    "20",
                    when (index % 2 == 0) {
                        true -> "credit"
                        false -> "debit"
                    },
                    "2019-09-09 09:09:09"
                )
            )
        }
        return list
    }
}