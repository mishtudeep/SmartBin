package com.android.smartbin.app

import android.app.Application
import androidx.multidex.MultiDexApplication
import com.android.smartbin.app.dagger.AppModule
import com.android.smartbin.app.dagger.DaggerAppComponent
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.util.TypeFaceUtil

class MainApplication :  MultiDexApplication() {
    companion object {
        lateinit var instance: MainApplication
    }

    private val appComponent by lazy {
        DaggerAppComponent
            .builder()
            .appModule(AppModule(this))
            .build()
    }

    fun appComponent() = appComponent

    override fun onCreate() {
        super.onCreate()

        instance = this

        TypeFaceUtil.overrideFonts(this)
        PreferenceUtil.instance.init(this)
    }
}