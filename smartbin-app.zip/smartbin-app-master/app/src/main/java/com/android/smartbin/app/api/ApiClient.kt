package com.android.smartbin.app.api

import com.android.smartbin.app.BuildConfig
import com.android.smartbin.app.MainApplication
import com.android.smartbin.app.util.ContextUtil
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ApiClient @Inject constructor() {
    private val retrofit by lazy {
        val httpClient = OkHttpClient.Builder()
        addNetworkConnectivityInterceptor(httpClient)
        addLoggingInterceptor(httpClient)
        setTimeoutValues(httpClient)
        createRetrofit(httpClient, BuildConfig.BASE_URL)
    }

    private fun addLoggingInterceptor(httpClient: OkHttpClient.Builder) {
        val interceptor = HttpLoggingInterceptor()
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        httpClient.addInterceptor(interceptor)
    }

    private fun addNetworkConnectivityInterceptor(httpClient: OkHttpClient.Builder) {
        httpClient.addInterceptor(object : NetworkConnectionInterceptor() {
            override fun isInternetAvailable(): Boolean {
                return ContextUtil.instance.isNetworkAvailable(MainApplication.instance)
            }
        })
    }

    fun get() = retrofit

    private fun createRetrofit(httpClient: OkHttpClient.Builder, baseUrl: String): Retrofit {
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(baseUrl)
            .client(httpClient.build())
            .build()
    }

    private fun setTimeoutValues(httpClient: OkHttpClient.Builder) {
        httpClient.connectTimeout(60, TimeUnit.SECONDS)
        httpClient.readTimeout(60, TimeUnit.SECONDS)
        httpClient.writeTimeout(60, TimeUnit.SECONDS)
    }
}