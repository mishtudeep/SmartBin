package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentProfileBinding
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_profile.*

class ProfileFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentProfileBinding
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.user = PreferenceUtil.instance.getUser()

        changePasswordAnc.setOnClickListener {
            navigate(R.id.action_profileFragment_to_changePasswordFragment)
        }
    }
}