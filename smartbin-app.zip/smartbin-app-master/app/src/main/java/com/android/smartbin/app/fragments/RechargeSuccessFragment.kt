package com.android.smartbin.app.fragments

class RechargeSuccessFragment : BaseFragment()