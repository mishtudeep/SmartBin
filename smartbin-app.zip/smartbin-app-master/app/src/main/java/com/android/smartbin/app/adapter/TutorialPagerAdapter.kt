package com.android.smartbin.app.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.android.smartbin.app.fragments.TutorialItemFragment

class TutorialPagerAdapter(
    private val tutorialHeaders: Array<String>,
    private val tutorialDesc: Array<String>,
    fm: FragmentManager
) : FragmentStatePagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        val fragment = TutorialItemFragment()
        fragment.arguments = Bundle().also {
            it.putString("description", tutorialDesc[position])
            it.putString("header", tutorialHeaders[position])
        }
        return fragment
    }

    override fun getCount(): Int {
        return tutorialHeaders.size
    }
}