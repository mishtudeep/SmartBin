package com.android.smartbin.app.util

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat

class PermissionManager(private val activityContext: Activity) {
    companion object {
        const val PERMISSION_REQUEST_CODE = 4001
    }

    private var permissionCallback: ((Boolean) -> Unit)? = null

    fun requestPermissions(permissions: Array<out String>, permissionCallback: (Boolean) -> Unit) {
        this.permissionCallback = permissionCallback
        if (isPermissionProvided(permissions)) permissionCallback.invoke(true)
        else ActivityCompat.requestPermissions(activityContext, permissions, PERMISSION_REQUEST_CODE)
    }

    private fun isPermissionProvided(permissions: Array<out String>): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions.all {
                ActivityCompat.checkSelfPermission(activityContext, it) == PackageManager.PERMISSION_GRANTED
            }
        } else {
            true
        }
    }

    fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray): Boolean {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            permissionProvided(grantResults).let {
                permissionCallback?.invoke(it)
                return it
            }
        } else {
            return false
        }
    }

    private fun permissionProvided(grantResults: IntArray): Boolean {
        return grantResults.all { it == PackageManager.PERMISSION_GRANTED }
    }
}