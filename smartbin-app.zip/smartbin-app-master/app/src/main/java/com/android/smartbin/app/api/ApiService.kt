package com.android.smartbin.app.api

import com.android.smartbin.app.models.DumpItem
import com.android.smartbin.app.models.DustBin
import com.android.smartbin.app.models.User
import com.android.smartbin.app.models.WalletTransaction
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import javax.inject.Singleton

@Singleton
@JvmSuppressWildcards
interface ApiService {
    @POST("user_login")
    @FormUrlEncoded
    suspend fun loginAsync(
        @Field("email") email: String,
        @Field("password") password: String
    ): Response<ApiResponse<User?>>

    @POST("user_registration")
    @FormUrlEncoded
    suspend fun registerAsync(
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("name") name: String
    ): Response<ApiResponse<User?>>

    @POST("start_dumping")
    @FormUrlEncoded
    suspend fun startDumpingAsync(
        @Field("user_id") userId: String,
        @Field("bin_id") binId: String
    ): Response<ApiResponse<String?>>

    @POST("stop_dumping")
    @FormUrlEncoded
    suspend fun stopDumpingAsync(
        @Field("dump_id") dumpId: String
    ): Response<ApiResponse<DumpItem?>>

    @POST("get_dump")
    @FormUrlEncoded
    suspend fun getDumpAsync(
        @Field("dump_id") dumpId: String
    ): Response<ApiResponse<DumpItem?>>

    @POST("verify_otp")
    @FormUrlEncoded
    suspend fun verifyOtpAsync(
        @Field("user_id") userId: String,
        @Field("otp") otp: String
    ): Response<ApiResponse<User?>>

    @POST("add_balance")
    @FormUrlEncoded
    suspend fun addBalanceAsync(
        @Field("user_id") userId: String,
        @Field("amount") amount: String
    ): Response<ApiResponse<User?>>

    @POST("user/otp_submission")
    @FormUrlEncoded
    suspend fun submitOtpAsync(
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("otp") otp: String
    ): Response<ApiResponse<String?>>

    @POST("dump_history")
    @FormUrlEncoded
    suspend fun getHistoryListAsync(
        @Field("user_id") userId: String
    ): Response<ApiResponse<List<DumpItem>?>>

    @POST("transaction_history")
    @FormUrlEncoded
    suspend fun getWalletTransactionsAsync(
        @Field("user_id") userId: String
    ): Response<ApiResponse<List<WalletTransaction>?>>

    @POST("get_bins_by_location")
    @FormUrlEncoded
    suspend fun getDustBinListAsync(
        @Field("user_id") userId: String,
        @Field("client_id") clientId: String,
        @Field("lat") lat: Double,
        @Field("lng") lng: Double
    ): Response<ApiResponse<List<DustBin>?>>
}