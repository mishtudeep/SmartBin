package com.android.smartbin.app.util

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.util.Log

object TypeFaceUtil {

    private const val REGULAR = 1
    private const val BOLD = 2
    private const val ITALIC = 3
    private const val BOLD_ITALIC = 4
    private const val LIGHT = 5
    private const val CONDENSED = 6
    private const val THIN = 7
    private const val MEDIUM = 8

    private const val SANS_SERIF = "sans-serif"
    private const val SANS_SERIF_LIGHT = "sans-serif-light"
    private const val SANS_SERIF_CONDENSED = "sans-serif-condensed"
    private const val SANS_SERIF_THIN = "sans-serif-thin"
    private const val SANS_SERIF_MEDIUM = "sans-serif-medium"

    private const val FIELD_DEFAULT = "DEFAULT"
    private const val FIELD_SANS_SERIF = "SANS_SERIF"
    private const val FIELD_SERIF = "SERIF"
    private const val FIELD_DEFAULT_BOLD = "DEFAULT_BOLD"

    fun overrideFonts(context: Context) {
        val regular = getTypeface(REGULAR, context)
        val light = getTypeface(REGULAR, context)
        val condensed = getTypeface(CONDENSED, context)
        val thin = getTypeface(THIN, context)
        val medium = getTypeface(MEDIUM, context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val fonts: MutableMap<String, Typeface> = mutableMapOf()
            fonts[SANS_SERIF] = regular
            fonts[SANS_SERIF_LIGHT] = light
            fonts[SANS_SERIF_CONDENSED] = condensed
            fonts[SANS_SERIF_THIN] = thin
            fonts[SANS_SERIF_MEDIUM] = medium
            overrideFontsMap(fonts)
        } else {
            overrideFont(FIELD_SANS_SERIF, getTypeface(REGULAR, context))
            overrideFont(FIELD_SERIF, getTypeface(REGULAR, context))
        }
        overrideFont(FIELD_DEFAULT, getTypeface(REGULAR, context))
        overrideFont(FIELD_DEFAULT_BOLD, getTypeface(BOLD, context))
    }

    /**
     * Using reflection to override default typefaces
     * NOTICE: DO NOT FORGET TO SET TYPEFACE FOR APP THEME AS DEFAULT TYPEFACE WHICH WILL BE
     * OVERRIDDEN
     *
     * @param typefaces map of fonts to replace
     */
    private fun overrideFontsMap(typefaces: MutableMap<String, Typeface>) {
        try {
            val field = Typeface::class.java.getDeclaredField("sSystemFontMap")
            field.isAccessible = true
            field.set(null, typefaces)
            field.isAccessible = false
        } catch (e: NoSuchFieldException) {
            Log.e("TypeFaceUtil", "Can not set custom fonts, NoSuchFieldException")
        } catch (e: IllegalAccessException) {
            Log.e("TypeFaceUtil", "Can not set custom fonts, IllegalAccessException")
        }

    }

    private fun overrideFont(fontName: String, typeface: Typeface) {
        try {
            val field = Typeface::class.java.getDeclaredField(fontName)
            field.isAccessible = true
            field.set(null, typeface)
            field.isAccessible = false
        } catch (e: Exception) {
            Log.e("TypeFaceUtil", "Can not set custom font $typeface instead of $fontName")
        }

    }

    private fun getTypeface(fontType: Int, context: Context): Typeface {
        return when (fontType) {
            ITALIC -> Typeface.create(SANS_SERIF, Typeface.ITALIC)
            BOLD_ITALIC -> Typeface.create(SANS_SERIF, Typeface.BOLD_ITALIC)
            CONDENSED -> Typeface.create(SANS_SERIF_CONDENSED, Typeface.NORMAL)
            THIN -> Typeface.create(SANS_SERIF_MEDIUM, Typeface.NORMAL)
            MEDIUM -> Typeface.create(SANS_SERIF_THIN, Typeface.NORMAL)
            BOLD -> Typeface.createFromAsset(context.assets, "fonts/Montserrat-Bold.ttf")
            REGULAR,
            LIGHT -> Typeface.createFromAsset(context.assets, "fonts/Montserrat-Regular.ttf")
            else -> Typeface.createFromAsset(context.assets, "fonts/Montserrat-Regular.ttf")
        }
    }

}