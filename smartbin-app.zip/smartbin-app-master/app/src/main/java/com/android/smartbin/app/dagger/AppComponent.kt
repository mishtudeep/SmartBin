package com.android.smartbin.app.dagger

import com.android.smartbin.app.viewmodel.UserViewModel
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = [AppModule::class])
interface AppComponent {
    fun inject(obj: UserViewModel)
}