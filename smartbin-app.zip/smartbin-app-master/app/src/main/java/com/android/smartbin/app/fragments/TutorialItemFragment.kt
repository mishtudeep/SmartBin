package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentTutorialItemBinding

class TutorialItemFragment : Fragment() {
    private lateinit var rootBinding: FragmentTutorialItemBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_tutorial_item, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            rootBinding.description = it.getString("description")
            rootBinding.header = it.getString("header")
        }
    }
}