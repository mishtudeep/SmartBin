package com.android.smartbin.app.util

object Constants {
    const val NETWORK_UNAVAILABLE_CODE = 405
    const val DUMPING_TIMER= 180
}