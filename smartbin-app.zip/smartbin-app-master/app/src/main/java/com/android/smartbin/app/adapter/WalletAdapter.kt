package com.android.smartbin.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.ItemWalletBinding
import com.android.smartbin.app.models.WalletTransaction

class WalletAdapter(
    private val context: Context,
    private val items: MutableList<WalletTransaction> = mutableListOf()
) : RecyclerView.Adapter<WalletViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WalletViewHolder {
        return WalletViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(context),
                R.layout.item_wallet,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: WalletViewHolder, position: Int) {
        holder.binding.transaction = items[position]
    }

    fun updateList(list: List<WalletTransaction>?) {
        if (list != null) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }
    }
}

class WalletViewHolder(val binding: ItemWalletBinding) : RecyclerView.ViewHolder(binding.root)