package com.android.smartbin.app.dagger

import android.app.Application
import android.content.Context
import com.android.smartbin.app.api.ApiClient
import com.android.smartbin.app.api.ApiService
import com.android.smartbin.app.repository.ApiRepository
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class AppModule(private val application: Application) {
    @Provides
    @Singleton
    fun providesApplication(): Application = application

    @Singleton
    @Provides
    fun providesContext(application: Application): Context = application.applicationContext

    @Singleton
    @Provides
    fun provideWebService(client: ApiClient): ApiService = client.get().create(ApiService::class.java)

    @Singleton
    @Provides
    fun providesApiRepository(apiService: ApiService): ApiRepository = ApiRepository(apiService)

}