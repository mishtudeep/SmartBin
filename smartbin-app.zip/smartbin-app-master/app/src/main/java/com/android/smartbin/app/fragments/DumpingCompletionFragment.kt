package com.android.smartbin.app.fragments

import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentaDumpingCompletionBinding
import com.android.smartbin.app.util.observeOnce
import com.android.smartbin.app.util.observeWithPredicate
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragmenta_dumping_completion.*

class DumpingCompletionFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentaDumpingCompletionBinding

    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragmenta_dumping_completion,
            container,
            false
        )
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.isProcessing = true

        userVM.lastDumpingStatusLD().observe(viewLifecycleOwner, Observer {
            if (it?.cost != null && it.cost.isNotEmpty()) {
                rootBinding.isProcessing = false
                rootBinding.cost = it.cost
                rootBinding.weight = it.weight
            } else {
                rootBinding.isProcessing = true
            }
        })

        userVM.fetchLastDumpingStatus()

        continueBtn.setOnClickListener {
            navigate(R.id.action_dumpingCompletionFragment_to_historyFragment)
        }
    }

    override fun onResume() {
        super.onResume()
        userVM.resetDumpingStatusLD()
    }
}