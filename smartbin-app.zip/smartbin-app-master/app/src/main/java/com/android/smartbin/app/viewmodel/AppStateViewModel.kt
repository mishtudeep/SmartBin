package com.android.smartbin.app.viewmodel

import android.os.Handler
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.smartbin.app.models.User
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.util.default

class AppStateViewModel : ViewModel() {
    enum class AppState {
        COLD,
        TUTORIAL,
        LOGIN,
        REGISTER,
        VERIFICATION,
        HOME
    }

    private val appStateLD: MutableLiveData<AppState?> = MutableLiveData<AppState?>().default(null)

    fun getAppState() = appStateLD

    private val currentUserLD = MutableLiveData<User?>().default(null)

    fun onSplashShown() {
        Handler().postDelayed({
            PreferenceUtil.instance.let {
                val appState = it.getAppState()
                if (appState == AppState.HOME) currentUserLD.value = it.getUser()
                appStateLD.postValue(determineNextState(appState))
            }
        }, 3000)
    }

    fun onTutorialCompleted() {
        PreferenceUtil.instance.saveAppState(AppState.TUTORIAL)
        appStateLD.postValue(AppState.LOGIN)
    }

    fun onSuccessfulLogin() {
        PreferenceUtil.instance.saveAppState(AppState.HOME)
        appStateLD.postValue(AppState.HOME)
    }

    private fun determineNextState(appState: AppState): AppState? {
        return when (appState) {
            AppState.COLD -> AppState.TUTORIAL
            AppState.TUTORIAL, AppState.LOGIN -> AppState.LOGIN
            AppState.HOME -> AppState.HOME
            AppState.REGISTER -> AppState.REGISTER
            AppState.VERIFICATION -> AppState.VERIFICATION
        }
    }
}