package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentRegistrationBinding
import com.android.smartbin.app.util.ValidityRule
import com.android.smartbin.app.util.addWatchers
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_registration.*


class RegistrationFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentRegistrationBinding
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_registration, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rootBinding.isSubmitEnabled = false
        rootBinding.loginAnc.setOnClickListener { navigateUp() }
        listOf(
            emailInputLayout to ValidityRule.EMAIL,
            passwordInputLayout to ValidityRule.PASSWORD,
            nameInputLayout to ValidityRule.NAME
        ).addWatchers { rootBinding.isSubmitEnabled = it }
        rootBinding.registerBtn.setOnClickListener {
            userVM.register(
                email = emailInput.text.toString(),
                password = passwordInput.text.toString(),
                name = nameInput.text.toString()
            ) {
                if (it != null) {
                    navigate(R.id.action_registrationFragment_to_verificationFragment)
                }
            }
        }
    }

    override fun isDrawerLocked(): Boolean = true
    override fun isAppBarRequired(): Boolean = false
}