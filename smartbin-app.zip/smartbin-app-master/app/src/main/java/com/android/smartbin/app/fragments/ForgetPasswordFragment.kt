package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentForgetpasswordBinding
import com.android.smartbin.app.util.ValidityRule
import com.android.smartbin.app.util.addWatchers
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_forgetpassword.*

class ForgetPasswordFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentForgetpasswordBinding
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_forgetpassword, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.isSubmitEnabled = false

        listOf(
            emailInputLayout to ValidityRule.EMAIL
        ).addWatchers { rootBinding.isSubmitEnabled = it }

        rootBinding.submitBtn.setOnClickListener {
            forgetPasswordEmail.text.toString().let {
                userVM.forgetPassword(it) { _ ->
                    navigateWithArgument(
                        R.id.action_forgetPasswordFragment_to_otpSubmissionFragment,
                        Bundle().also { b -> b.putString("phone", it) }
                    )
                }
            }

        }
        rootBinding.backBtn.setOnClickListener { navigateUp() }
    }

    override fun isDrawerLocked(): Boolean = true

    override fun isAppBarRequired(): Boolean = false
}