package com.android.smartbin.app.models

import com.android.smartbin.app.util.toReadableTimeStamp
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class DumpItem(
    @SerializedName("dump_id") val dumpId: String,
    @SerializedName("bin") val dustBin: DustBin,
    @SerializedName("weight") val weight: String,
    @SerializedName("cost") val cost: String,
    @SerializedName("currency") val currency: String = "€",
    @SerializedName("updated_on") val updatedOn: String
) : Serializable {
    fun toReadableTimeStamp() : String {
        return updatedOn.toReadableTimeStamp()
    }
}