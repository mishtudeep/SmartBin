package com.android.smartbin.app.api

import com.android.smartbin.app.util.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.ResponseBody.Companion.toResponseBody

abstract class NetworkConnectionInterceptor : Interceptor {
    abstract fun isInternetAvailable(): Boolean

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!isInternetAvailable()) {
            return Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .message("Network connection error")
                .code(Constants.NETWORK_UNAVAILABLE_CODE)
                .body("".toResponseBody("application/error".toMediaTypeOrNull()))
                .build()
        }
        return chain.proceed(request)
    }
}