package com.android.smartbin.app.fragments

import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.android.smartbin.app.MainActivity
import com.android.smartbin.app.R
import com.android.smartbin.app.models.DustBin
import com.android.smartbin.app.util.toLatLng
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapFragment(
    private var bins: MutableList<DustBin>? = null,
    private val markerCallback: ((DustBin?) -> Unit)? = null
) : BaseFragment() {
    private var mapFragment: SupportMapFragment? = null
    private var googleMap: GoogleMap? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_map_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mapFragment = childFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment?.getMapAsync {
            googleMap = it
            addMarkerClickListeners()
            renderBins()

            (activity as MainActivity).locationUtil().getLocationLD().observe(viewLifecycleOwner, Observer { location ->
                renderCurrentLocation(location)
            })
        }
    }

    private fun renderBins() {
        if (googleMap != null) {
            googleMap?.clear()
            bins?.forEach {
                it.toLatLng()?.let { latLng ->  googleMap?.addMarker(
                    MarkerOptions()
                        .position(latLng)
                        .title(it.addressLine1)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                        .draggable(false)
                        .visible(true)
                )?.tag = it.dustbinId}
            }
        }
    }

    private var isCameraUpdated = false
    private var locationMarker: Marker? = null
    private fun renderCurrentLocation(location: Location?) {
        if (googleMap != null) {
            locationMarker?.remove()
            location.toLatLng()?.let {
                locationMarker = googleMap?.addMarker(
                    MarkerOptions()
                        .position(it)
                        .title("My Location")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                        .draggable(false)
                        .visible(true)
                )
                locationMarker?.tag = "-1"
                if (!isCameraUpdated) {
                    val cameraUpdate = CameraUpdateFactory.newLatLngZoom(it, 18f)
                    googleMap?.animateCamera(cameraUpdate)
                    isCameraUpdated = true
                }
            }
        }
    }

    private fun addMarkerClickListeners() {
        googleMap?.setOnInfoWindowClickListener { marker ->
            markerCallback?.invoke(bins?.find { it.dustbinId == marker.tag as String })
        }
    }

    fun updateBins(bins: List<DustBin>) {
        if (this.bins == null) this.bins = mutableListOf()
        this.bins?.clear()
        this.bins?.addAll(bins)
        renderBins()
    }
}