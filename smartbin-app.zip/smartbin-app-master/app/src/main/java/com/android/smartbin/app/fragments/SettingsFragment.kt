package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentSettingsBinding

class SettingsFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentSettingsBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_settings, container, false)
        return rootBinding.root
    }
}