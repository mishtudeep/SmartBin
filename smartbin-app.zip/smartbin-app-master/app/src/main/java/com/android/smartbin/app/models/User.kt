package com.android.smartbin.app.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class User(
    @SerializedName("user_id") val userId: String,
    @SerializedName("first_name") val firstName: String,
    @SerializedName("last_name") val lastName: String,
    @SerializedName("address_line_1") val addressLine1: String,
    @SerializedName("address_line_2") val addressLine2: String,
    @SerializedName("email") val email: String,
    @SerializedName("phone") val phone: String,
    @SerializedName("profile_pic") val profilePic: String,
    @SerializedName("referral_code") val referralCode: String,
    @SerializedName("wallet_balance") val balance: String,
    @SerializedName("currency") val currency: String = "€",
    @SerializedName("updated_on") val updatedOn: String,
    @SerializedName("client") val client: BinClient
) : Serializable