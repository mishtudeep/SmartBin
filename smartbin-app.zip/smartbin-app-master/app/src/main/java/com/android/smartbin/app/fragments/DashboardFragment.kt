package com.android.smartbin.app.fragments

import android.Manifest
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.MainActivity
import com.android.smartbin.app.R
import com.android.smartbin.app.models.DustBin
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_dashboard.*

class DashboardFragment : BaseFragment() {
    private val mapFragment by lazy {
        MapFragment { dustbin ->
            if (dustbin != null) {
                (activity as MainActivity).initiateScan {
                    println("binID: " + it.binId)
                    println("clientId: " + it.clientId)
                    if (it.binId == dustbin.dustbinId/* && location != null && location!!.distanceTo(
                            dustbin.toLocation()
                        ) <= 10*/
                    ) {
                        navigateWithArgument(
                            R.id.action_dashboardFragment_to_wasteDumpFragment,
                            Bundle().also { bundle ->
                                bundle.putSerializable("dustbin", dustbin)
                            })
                    }
                }

//                navigateWithArgument(
//                    R.id.action_dashboardFragment_to_wasteDumpFragment,
//                    Bundle().also { bundle ->
//                        bundle.putSerializable("dustbin", dustbin)
//                    })
            }
        }
    }
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }
    private var lastLocation: Location? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainActivity).let {
            it.permissionManager().requestPermissions(
                permissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            ) { granted ->
                if (granted) {
                    it.locationUtil().let { locationUtil ->
                        locationUtil.onCreate()
                        locationUtil.getLocationLD().observe(viewLifecycleOwner,
                            Observer { location ->
                                if (location != null && (lastLocation == null || location.distanceTo(
                                        lastLocation
                                    ) > 1000)
                                ) {
                                    userVM.fetchDustBinList(location)
                                    lastLocation = location
                                }
                            })
                    }
                }
            }
        }

        replaceFragment(R.id.mapContainer, mapFragment)
        userVM.dustBinListLD().observe(viewLifecycleOwner, Observer {
            if (!it.isNullOrEmpty()) mapFragment.updateBins(it)
        })

        dummyBtn.setOnClickListener {
            navigateWithArgument(R.id.action_dashboardFragment_to_wasteDumpFragment, Bundle().also {
                it.putSerializable("dustbin", DustBin())
            })
        }
    }

}