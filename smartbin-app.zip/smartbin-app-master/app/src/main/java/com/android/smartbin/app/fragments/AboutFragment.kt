package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentAboutBinding

class AboutFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentAboutBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_about, container, false)
        return rootBinding.root
    }
}