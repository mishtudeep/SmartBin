package com.android.smartbin.app.adapter

import android.content.Context
import android.view.ContextMenu
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.ItemHistoryBinding
import com.android.smartbin.app.models.DumpItem

class HistoryAdapter(
    private val context: Context,
    var historyItems: MutableList<DumpItem> = mutableListOf()
) : RecyclerView.Adapter<HistoryViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        return HistoryViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(context),
                R.layout.item_history,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return historyItems.size
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.binding.historyItem = historyItems[position]
    }

    fun updateList(list: List<DumpItem>) {
        historyItems.clear()
        historyItems.addAll(list)
        notifyDataSetChanged()
    }
}

class HistoryViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)