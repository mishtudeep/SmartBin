package com.android.smartbin.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.android.smartbin.app.databinding.ActivityMainBinding
import com.android.smartbin.app.dialog.LoadingDialog
import com.android.smartbin.app.models.DustbinQrObj
import com.android.smartbin.app.util.LocationUtil
import com.android.smartbin.app.util.PermissionManager
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.viewmodel.LoadingStatus
import com.android.smartbin.app.viewmodel.UserViewModel
import com.google.gson.Gson
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private lateinit var rootBinding: ActivityMainBinding
    private lateinit var navController: NavController
    private val userVM by lazy { ViewModelProviders.of(this)[UserViewModel::class.java] }
    private val permissionManager by lazy { PermissionManager(this) }
    private val loadingDialog by lazy { LoadingDialog() }
    private val locationUtil: LocationUtil by lazy { LocationUtil(this) }
    private val qrCodeScanner: IntentIntegrator by lazy {
        IntentIntegrator(this).also {
            it.setCameraId(0)
            it.setPrompt("Scan the QR Code")
            it.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES)
            it.setOrientationLocked(false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        rootBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        rootBinding.buildNumber = BuildConfig.VERSION_NAME
        rootBinding.debug = BuildConfig.DEBUG

        setupNavigation()

        setupLoadingObserver()

        parentLayout.setOnClickListener { hideKeyboard() }
    }

    private fun setupLoadingObserver() {
        userVM.getLoadingStatusLD().observe(this, Observer {
            try {
                if (it != null) {
                    when (it) {

                        LoadingStatus.LOADING_STARTED -> {
                            try {
                                if (!loadingDialog.isAdded) {
                                    loadingDialog.show(
                                        supportFragmentManager,
                                        "loading dialog"
                                    )
                                }
                            } catch (ex: Exception) {
                                ex.printStackTrace()
                            }
                        }
                        LoadingStatus.LOADING_ENDED -> loadingDialog.dismiss()
                    }
                }
            } catch (exception: Exception) {
                exception.printStackTrace()
            }
        })
    }

    private fun setupNavigation() {
        navController = NavHostFragment.findNavController(navHostFragment)
        setupActionBar()
        initiateNavMenu()
    }

    private val navIds = mutableListOf(
        R.id.navHome to R.id.dashboardFragment,
        R.id.navProfile to R.id.profileFragment,
        R.id.navSettings to R.id.settingsFragment,
        R.id.navHistory to R.id.historyFragment,
        R.id.navWallet to R.id.walletFragment,
        R.id.navAbout to R.id.aboutFragment,
        R.id.navLogout to null
    )

    private fun initiateNavMenu() {
        navIds.forEach { (navId, navDestinationId) ->
            navigationView.findViewById<TextView>(navId).setOnClickListener {
                if (navDestinationId != null) {
                    navigate(navDestinationId)
                } else {
                    // handle logout
                    PreferenceUtil.instance.logout()
                    Handler().postDelayed({
                        navigate(R.id.action_global_loginFragment)
                    }, 1000)
                }
                drawerLayout.closeDrawer(GravityCompat.START)
            }
        }
    }

    fun navigate(destinationId: Int, arguments: Bundle? = null) {
        navController.navigate(destinationId, arguments)
    }

    private var appBarConf: AppBarConfiguration? = null
    private fun setupActionBar() {
        setSupportActionBar(toolbar)
        if (appBarConf == null) createAppBarConf()
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConf!!)
    }

    private fun createAppBarConf() {
        appBarConf = AppBarConfiguration.Builder(
            R.id.dashboardFragment,
            R.id.profileFragment,
            R.id.settingsFragment,
            R.id.aboutFragment,
            R.id.historyFragment,
            R.id.walletFragment
        ).setDrawerLayout(drawerLayout).build()
    }

    fun update(appBarRequired: Boolean, drawerLocked: Boolean) {
        when {
            appBarRequired -> appBarLayout.visibility = View.VISIBLE
            else -> appBarLayout.visibility = View.GONE
        }
        when {
            drawerLocked -> drawerLayout.setDrawerLockMode(
                DrawerLayout.LOCK_MODE_LOCKED_CLOSED,
                GravityCompat.START
            )
            else -> drawerLayout.setDrawerLockMode(
                DrawerLayout.LOCK_MODE_UNLOCKED,
                GravityCompat.START
            )
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        if (appBarConf == null) createAppBarConf()
        return NavigationUI.navigateUp(navController, appBarConf!!)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (!permissionManager.onRequestPermissionsResult(requestCode, grantResults))
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    fun hideKeyboard() {
        val imm = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        var view = currentFocus
        if (view == null) view = View(this)
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private var qrCallback: ((DustbinQrObj) -> Unit)? = null
    private var qrResultObj: DustbinQrObj? = null
    private var caterActivityResultData: Boolean = false
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!locationUtil.onActivityResult(requestCode, resultCode, data)) {
            val qrCodeResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            if (qrCodeResult != null) {
                qrCodeResult.contents?.let {
                    println("RESULT: $it")
                    val qrResultObj = Gson().fromJson<DustbinQrObj>(it, DustbinQrObj::class.java)
                    this.qrResultObj = qrResultObj
                    this.caterActivityResultData = true
                }
            } else {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (caterActivityResultData && qrCallback != null && qrResultObj != null) {
            qrCallback?.invoke(qrResultObj!!)
            caterActivityResultData = false
            qrCallback = null
            qrResultObj = null
        }
    }

    fun initiateScan(qrCallback: (DustbinQrObj) -> Unit) {
        this.qrCallback = qrCallback
        qrCodeScanner.initiateScan()
    }

    fun permissionManager() = permissionManager

    fun locationUtil() = locationUtil
}