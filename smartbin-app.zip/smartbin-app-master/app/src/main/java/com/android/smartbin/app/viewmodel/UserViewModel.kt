package com.android.smartbin.app.viewmodel

import android.location.Location
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.smartbin.app.MainApplication
import com.android.smartbin.app.models.DumpItem
import com.android.smartbin.app.models.DustBin
import com.android.smartbin.app.models.User
import com.android.smartbin.app.models.WalletTransaction
import com.android.smartbin.app.repository.ApiRepository
import com.android.smartbin.app.util.Constants
import com.android.smartbin.app.util.Constants.DUMPING_TIMER
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.util.default
import com.android.smartbin.app.util.toMinuteString
import kotlinx.coroutines.*
import java.util.concurrent.ExecutorService
import javax.inject.Inject
import kotlin.coroutines.CoroutineContext

class UserViewModel : ViewModel() {
    private val parentJob = Job()
    private val coroutineContext: CoroutineContext by lazy { parentJob + Dispatchers.Default }
    private val scope = CoroutineScope(coroutineContext)
    fun cancelAllRequest() = coroutineContext.cancel()

    @Inject
    lateinit var apiRepository: ApiRepository
    /*
    * loading status section
    * */
    private val loadingStatusLD = MutableLiveData<LoadingStatus?>().default(null)

    fun getLoadingStatusLD() = loadingStatusLD

    init {
        MainApplication.instance.appComponent().inject(this)
        apiRepository.setStatusLD(loadingStatusLD)
    }

    /*
    * login
    * */
    fun login(email: String, password: String, callback: (Boolean) -> Unit) {
        scope.launch {
            val user = apiRepository.login(email, password)
            PreferenceUtil.instance.saveUser(user)
            PreferenceUtil.instance.saveAppState(AppStateViewModel.AppState.HOME)
            withContext(Dispatchers.Main) {
                callback.invoke(user != null)
            }
        }
    }

    /*
    * forget password
    * */
    fun forgetPassword(email: String, callback: (Boolean) -> Unit) {
        scope.launch {
            val success = apiRepository.forgetPassword(email)
            withContext(Dispatchers.Main) {
                callback.invoke(success)
            }
        }
    }

    /*
    * forget password otp submission
    * */
    fun submitOTP(email: String, otp: String, password: String, callback: (Boolean) -> Unit) {
        scope.launch {
            val success = apiRepository.submitOTP(email, otp, password)
            withContext(Dispatchers.Main) {
                callback.invoke(success)
            }
        }
    }

    /*
    * registration
    * */
    fun register(name: String, email: String, password: String, callback: (User?) -> Unit) {
        scope.launch {
            val user = apiRepository.register(name, email, password)
            PreferenceUtil.instance.saveUser(user)
            PreferenceUtil.instance.saveAppState(AppStateViewModel.AppState.VERIFICATION)
            withContext(Dispatchers.Main) {
                callback.invoke(user)
            }
        }
    }

    /*
    * verify OTP after registration
    * */
    fun verifyOtp(otp: String, callback: (Boolean) -> Unit) {
        scope.launch {
            val success = apiRepository.verifyOtp(otp)
            withContext(Dispatchers.Main) {
                callback.invoke(success)
            }
        }
    }

    /*
    * dust bin list based on location
    * */
    private val dustBinListLD = MutableLiveData<List<DustBin>?>().default(null)

    fun dustBinListLD() = dustBinListLD

    fun fetchDustBinList(location: Location?) {
        scope.launch {
            dustBinListLD.postValue(apiRepository.fetchDustBinList(location))
        }
    }

    /*
    * get dump history
    * */
    private val dumpHistoryLD = MutableLiveData<List<DumpItem>?>().default(null)

    fun getDumpHistoryLD() = dumpHistoryLD

    fun fetDumpHistoryList() {
        scope.launch {
            dumpHistoryLD.postValue(apiRepository.getDumpHistory())
        }
    }

    /*
    * wallet transactions
    * */
    private val walletTransactionLD = MutableLiveData<List<WalletTransaction>?>().default(null)

    fun getWalletTransactionsLD() = walletTransactionLD

    fun fetchWalletTransactions() {
        scope.launch {
            walletTransactionLD.postValue(apiRepository.getWalletTransactions())
        }
    }

    /*
    * dumping timer
    * */
    private val dumpingTimerLD =
        MutableLiveData<String?>().default(DUMPING_TIMER.toMinuteString())

    fun getDumpingTimeLD() = dumpingTimerLD

    fun resetDumpingTimeLD() {
        dumpingTimerLD.postValue(DUMPING_TIMER.toMinuteString())
    }

    private val completeBtnTextLD = MutableLiveData<String>().default("Start")

    fun completeBtnTextLD() = completeBtnTextLD

    private var isTimerActive: Boolean = false

    private val dumpingIdPersistentLD = MutableLiveData<String?>().default(null)

    fun startDumpingTimer(binId: String, callback: () -> Unit) {
        if (binId.isBlank()) return

        scope.launch {
            val dumpingId = apiRepository.startDumping(binId)
            dumpingIdPersistentLD.postValue(dumpingId)
            if (dumpingId != null) {
                completeBtnTextLD.postValue("Complete")
                isTimerActive = true
                var count = 0
                while (count <= DUMPING_TIMER && isTimerActive) {
                    dumpingTimerLD.postValue((DUMPING_TIMER - count).toMinuteString())
                    count += 1
                    Thread.sleep(1000)
                    if (count == DUMPING_TIMER) withContext(Dispatchers.Main) { callback.invoke() }
                }
            }
        }
    }

    fun stopDumpingTimer() {
        scope.launch {
            apiRepository.stopDumping(dumpingIdPersistentLD.value)
        }
        isTimerActive = false
    }

    fun isDumping() = isTimerActive

    private val lastDumpingStatusLD = MutableLiveData<DumpItem?>().default(null)

    fun lastDumpingStatusLD() = lastDumpingStatusLD

    fun resetDumpingStatusLD() {
        lastDumpingStatusLD.postValue(null)
    }

    fun fetchLastDumpingStatus() {
        scope.launch {
            var count = 0
            while (count <= 3) {
                val dump = apiRepository.getDumpStatus(dumpingIdPersistentLD.value ?: "")
                lastDumpingStatusLD.postValue(dump)
                count += 1
                if (!dump?.cost.isNullOrEmpty()) break
                Thread.sleep(5000)
            }
        }
    }

    /*
    * add balance
    * */
    fun addBalanceAsync(amount: String, callback: (User) -> Unit) {
        scope.launch {
            val user = apiRepository.addBalanceAsync(amount = amount)
            if (user != null) {
                PreferenceUtil.instance.saveUser(user)
                withContext(Dispatchers.Main) {
                    callback.invoke(user)
                }
            }
        }
    }
}

enum class LoadingStatus {
    LOADING_STARTED, LOADING_ENDED
}