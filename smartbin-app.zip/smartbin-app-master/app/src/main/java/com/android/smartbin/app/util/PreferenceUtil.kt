package com.android.smartbin.app.util

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import com.android.smartbin.app.models.User
import com.android.smartbin.app.viewmodel.AppStateViewModel
import com.google.gson.Gson

class PreferenceUtil {
    private lateinit var sharedPref: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    companion object {
        val instance = PreferenceUtil()
    }

    fun init(context: Context) {
        sharedPref = context.getSharedPreferences("Prefs", Activity.MODE_PRIVATE)
    }

    private fun getString(key: String, defValue: String = ""): String? {
        return sharedPref.getString(key, defValue)
    }

    private fun putString(key: String, value: String?) {
        editor = sharedPref.edit()
        editor.putString(key, value).apply()
        editor.commit()
    }

    fun getUser(): User? {
        val userJson = getString("user")
        return if (userJson == null || userJson.isEmpty()) null
        else Gson().fromJson(userJson, User::class.java)
    }

    fun logout() {
        saveUser(null)
        saveAppState(AppStateViewModel.AppState.LOGIN)
    }

    fun saveUser(userModel: User?) {
        putString("user", Gson().toJson(userModel))
    }

    fun getAppState(): AppStateViewModel.AppState {
        val appStateString = getString("app_state")
        return when {
            appStateString.isNullOrEmpty() -> AppStateViewModel.AppState.COLD
            appStateString == "tutorial" -> AppStateViewModel.AppState.TUTORIAL
            appStateString == "home" -> AppStateViewModel.AppState.HOME
            appStateString == "login" -> AppStateViewModel.AppState.LOGIN
            appStateString == "register" -> AppStateViewModel.AppState.REGISTER
            appStateString == "verification" -> AppStateViewModel.AppState.VERIFICATION
            else -> AppStateViewModel.AppState.LOGIN
        }
    }

    fun saveAppState(state: AppStateViewModel.AppState) {
        when (state) {
            AppStateViewModel.AppState.TUTORIAL -> putString("app_state", "tutorial")
            AppStateViewModel.AppState.HOME -> putString("app_state", "home")
            AppStateViewModel.AppState.LOGIN -> putString("app_state", "login")
            AppStateViewModel.AppState.COLD -> putString("app_state", "")
            AppStateViewModel.AppState.REGISTER -> putString("app_state", "register")
            AppStateViewModel.AppState.VERIFICATION -> putString("app_state", "verification")
        }
    }
}