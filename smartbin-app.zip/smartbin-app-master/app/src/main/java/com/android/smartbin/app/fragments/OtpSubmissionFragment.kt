package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.databinding.FragmentOtpSubmissionBinding
import com.android.smartbin.app.util.ValidityRule
import com.android.smartbin.app.util.addWatchers
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_otp_submission.*

class OtpSubmissionFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentOtpSubmissionBinding
    private val userVM by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_otp_submission, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rootBinding.isSubmitEnabled = false

        listOf(
            otpInputLayout to ValidityRule.OTP,
            passwordInputLayout to ValidityRule.PASSWORD
        ).addWatchers {
            rootBinding.isSubmitEnabled = it
        }

        submitBtn.setOnClickListener {
            userVM.submitOTP(
                arguments?.getString("email") ?: "",
                otpInput.text.toString(),
                passwordInput.text.toString()
            ) {
                navigate(R.id.action_otpSubmissionFragment_to_loginFragment)
            }
        }

        rootBinding.backBtn2.setOnClickListener { navigateUp() }
    }

    override fun isDrawerLocked(): Boolean = true

    override fun isAppBarRequired(): Boolean = false
}