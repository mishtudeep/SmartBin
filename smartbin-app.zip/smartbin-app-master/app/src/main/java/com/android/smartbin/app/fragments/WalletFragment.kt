package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.smartbin.app.R
import com.android.smartbin.app.adapter.WalletAdapter
import com.android.smartbin.app.databinding.FragmentWalletBinding
import com.android.smartbin.app.models.User
import com.android.smartbin.app.util.PreferenceUtil
import com.android.smartbin.app.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_wallet.*

class WalletFragment : BaseFragment() {
    private lateinit var rootBinding: FragmentWalletBinding
    private val userVM: UserViewModel by lazy {
        ViewModelProviders.of(activity!!)[UserViewModel::class.java]
    }
    private var adapter: WalletAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_wallet, container, false)
        return rootBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        PreferenceUtil.instance.getUser()?.let {
            rootBinding.user = it
        }

        if (adapter == null) {
            adapter = WalletAdapter(activity!!)
            walletRecycler.layoutManager = LinearLayoutManager(activity!!)
            walletRecycler.adapter = adapter
        }

        userVM.getWalletTransactionsLD().observe(viewLifecycleOwner, Observer {
            walletRefresh.isRefreshing = false
            adapter?.updateList(it)
        })

        userVM.fetchWalletTransactions()

        walletRefresh.setOnRefreshListener {
            userVM.fetchWalletTransactions()
        }

        button.setOnClickListener {
            val amount = amountInput.text.toString()
            if (amount.isNotEmpty()) {
                userVM.addBalanceAsync(amount = amount) {
                    amountInput.text?.clear()
                    rootBinding.user = it
                }
            }
        }
    }
}