package com.android.smartbin.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.smartbin.app.R
import com.android.smartbin.app.adapter.TutorialPagerAdapter
import com.android.smartbin.app.viewmodel.AppStateViewModel
import kotlinx.android.synthetic.main.fragment_tutorial.*

class TutorialFragment : BaseFragment() {
    private lateinit var appStateViewModel: AppStateViewModel
    private lateinit var stateObserver: Observer<AppStateViewModel.AppState?>
    private lateinit var tutorialHeaders: Array<String>
    private lateinit var tutorialDesc: Array<String>


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_tutorial, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tutorialHeaders = activity!!.resources.getStringArray(R.array.tutorial_items_header)
        tutorialDesc = activity!!.resources.getStringArray(R.array.tutorial_items_desc)
        val adapter = TutorialPagerAdapter(tutorialHeaders, tutorialDesc, childFragmentManager)
        tutorialPager.adapter = adapter

        appStateViewModel = ViewModelProviders.of(activity!!)[AppStateViewModel::class.java]

        appStateViewModel.getAppState().let { ld ->
            stateObserver = Observer {
                if (it != null && it == AppStateViewModel.AppState.LOGIN) {
                    navigate(R.id.action_tutorialFragment_to_loginFragment)
                    ld.removeObserver(stateObserver)
                }
            }
            ld.observe(viewLifecycleOwner, stateObserver)
        }

        nextBtn.setOnClickListener {
            tutorialPager.currentItem.let {
                if (it + 1 < tutorialHeaders.size) tutorialPager.setCurrentItem(it + 1, true)
                if (it == tutorialHeaders.size - 1) appStateViewModel.onTutorialCompleted()
            }
        }

        prevBtn.setOnClickListener {
            tutorialPager.currentItem.let {
                if (it - 1 >= 0) tutorialPager.setCurrentItem(it - 1, true)
            }
        }
    }

    override fun isDrawerLocked(): Boolean = true
    override fun isAppBarRequired(): Boolean = false
}