import React from "react";
import { Redirect } from "react-router-dom";

// Layout Types
import { DefaultLayout, LoginLayout } from "./layouts";

// Route Views
import BlogOverview from "./views/BlogOverview";
import Errors from "./views/Errors";
import Client from './views/Users';
import ComponentsOverview from "./views/ComponentsOverview";
import Tables from "./views/Tables";
import BlogPosts from "./views/BlogPosts";
import Login from './views/Login';
import User from './views/User';
import Bin from './views/Bin';
import Dump from './views/Dump';

const routes = [
  {
    path: "/login",
    layout: LoginLayout,
    key: "login",
    component: Login
  },
  {
    path: "/bin",
    layout: DefaultLayout,
    key: "bin",
    component: Bin
  },
  {
    path: "/dump",
    layout: DefaultLayout,
    key: "dump",
    component: Dump
  },
  {
    path: "/dashboard",
    layout: DefaultLayout,
    key: "dashboard",
    component: BlogOverview
  },
  {
    path: "/clients",
    layout: DefaultLayout,
    key: "clients",
    component: BlogPosts
  },
  {
    path: "/client",
    layout: DefaultLayout,
    key: "client",
    component: Client
  },
  {
    path: "/user",
    layout: DefaultLayout,
    key: "user",
    component: User
  },
  {
    path: "/errors",
    layout: DefaultLayout,
    component: Errors
  },
  {
    path: "/components",
    layout: DefaultLayout,
    component: ComponentsOverview
  },
  {
    path: "/tables",
    layout: DefaultLayout,
    component: Tables
  },
  {
    path: "/blog-posts",
    layout: DefaultLayout,
    component: BlogPosts
  }
];

export var getRoutes = () => {
  var user = localStorage.getItem("user");
  console.log("routes user: ", user);
  if (user == undefined || user == null) {
    console.log("redirecting to login");
    return [...routes, {
      path: '/',
      redirect: true,
      to: 'login'
    }];
  } else {
    console.log("redirecting to dashboard");
    return [...routes, {
      path: '/',
      redirect: true,
      to: 'dashboard'
    }];
  }
}