import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

class UserList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedUserId: -1,
      isUserSelected: false,
    };

    this.onUserSelected = this.onUserSelected.bind(this);
  }

  onUserSelected(userId = 1) {
    this.setState({
      ...this.state, selectedUserId: userId, isUserSelected: true
    });
  }

  render() {
    console.log('user', this.props.data);
    if (this.props.data == undefined) {

    } else {
      if (this.state.isUserSelected) {
        return (
          <Redirect push key={`user#${this.state.selectedUserId}`} to={`/user/${this.state.selectedUserId}`} />
        )
      } else {
        return (
          <Row>
            {this.props.data.map((post, idx) => (
              <Col lg="6" sm="12" className="mb-4" key={idx}>
                <Card small style={{
                  cursor: 'pointer'
                }} className="card-post card-post--aside card-post--1" onClick={() => this.onUserSelected(post.user_id)}>
                  {/* <div
                    className="card-post__image"
                    style={{
                      backgroundImage: `url('${require("../images/content-management/1.jpeg")}')`,
                    }}
                  >
                    <Badge
                      pill
                      className={`card-post__category bg-royal-blue`}
                    >
                      NEW
                  </Badge>
                  </div> */}
                  <CardBody>
                    <h5 className="card-title">
                      <span className="text-fiord-blue">
                        {`${post.first_name} ${post.last_name}`}
                      </span>
                    </h5>
                    <p className="card-text mb-3">Email: {post.email}</p>
                    <p className="text-muted">Balance: {`${post.currency}${post.wallet_balance}`}</p>
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        );
      }
    }

    
  }
}

export default UserList;