import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

class BinsList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedBinId: 1,
      isBinSelected: false,
    };

    this.onBinSelected = this.onBinSelected.bind(this);
  }

  onBinSelected(binId = 1) {
    this.setState({
      ...this.state, selectedBinId: binId, isBinSelected: true
    });
  }

  componentWillMount() {
    console.log(window.location.href);
  }

  render() {

    if (this.props.data == undefined) {

    } else {
      if (this.state.isBinSelected) {
        return (
          <Redirect push key={`bin#${this.state.selectedBinId}`} to={`/bin/${this.state.selectedBinId}`} />
        );
      } else {
        return (
          <Row>
            {this.props.data.map((post, idx) => (
              <Col lg="6" sm="12" className="mb-4" key={idx}>
                <Card small style={{
                  cursor: 'pointer'
                }} className="card-post card-post--aside card-post--1" onClick={() => this.onBinSelected(post.bin_id)}>
                  <div
                    className="card-post__image"
                    style={{
                      backgroundImage: `url('${require("../images/content-management/1.jpeg")}')`,
                      cursor: 'pointer'
                    }}
                  >
                    <Badge
                      pill
                      className={`card-post__category bg-royal-blue`}
                    >
                      NEW
                  </Badge>
                  </div>
                  <CardBody>
                    <h5 className="card-title">
                      <span className="text-fiord-blue">
                        {post.house_name}
                      </span>
                    </h5>
                    <p className="card-text d-inline-block mb-3">{post.address_line_1}</p>
                    <p className="card-text mb-3">Dimension(in cm): {`${post.height}x${post.width}x${post.length}`}</p>
                    <p className="card-text"> Current Weight: {post.current_weight} kg ({post.filled_percent}% filled)</p>
                    <p className="text-muted"> Capacity: {post.capacity} kg</p>
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        );
      }
    }

  }
}

export default BinsList;