import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge,
  Button
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

class DumpsList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedDumpId: -1,
      isDumpSelected: false,
      selectedUserId: -1,
      isUserSelected: false,
      selectedBinId: -1,
      isBinSelected: false
    };

    this.onDumpSelected = this.onDumpSelected.bind(this);
    this.onBinSelected = this.onBinSelected.bind(this);
    this.onUserSelected = this.onUserSelected.bind(this);
  }

  onUserSelected(userId) {
    this.setState({
      ...this.state,
      selectedDumpId: -1, isDumpSelected: false,
      selectedUserId: userId, isUserSelected: true,
      selectedBinId: -1, isBinSelected: false
    });
  }

  onBinSelected(binId) {
    this.setState({
      ...this.state,
      selectedDumpId: -1, isDumpSelected: false,
      selectedUserId: -1, isUserSelected: false,
      selectedBinId: binId, isBinSelected: true
    });
  }

  onDumpSelected(dumpId) {
    this.setState({
      ...this.state,
      selectedDumpId: dumpId, isDumpSelected: true,
      selectedUserId: -1, isUserSelected: false,
      selectedBinId: -1, isBinSelected: false
    });
  }

  componentWillMount() {
    console.log(window.location.href);
  }

  render() {
    if (this.state.isDumpSelected) {
      return (
        <Redirect push key={`dump#${this.state.selectedDumpId}`} to={`/dump/${this.state.selectedDumpId}`} />
      );
    } else if (this.state.isUserSelected) {
      return (
        <Redirect push key={`user#${this.state.selectedUserId}`} to={`/user/${this.state.selectedUserId}`} />
      );
    } else if (this.state.isBinSelected) {
      return (
        <Redirect push key={`bin#${this.state.selectedBinId}`} to={`/bin/${this.state.selectedBinId}`} />
      );
    } else {
      return (
        <Row>
          <table className="table mb-0">
            <thead className="bg-light">
              <tr>
                <th scope="col" className="border-0">
                  #
                  </th>
                <th scope="col" className="border-0">
                  User
                  </th>
                <th scope="col" className="border-0">
                  Bin
                  </th>
                <th scope="col" className="border-0">
                  Weight
                  </th>
                <th scope="col" className="border-0">
                  Cost
                  </th>
                <th scope="col" className="border-0">
                  Time
                  </th>
                <th scope="col" className="border-0">
                  Action
                  </th>
              </tr>
            </thead>
            <tbody>
              {
                this.props.data.map((dump, idx) => (
                  <tr>
                    <td>{dump.dump_id}</td>
                    <td>{dump.user_id}</td>
                    <td>{dump.bin_id}</td>
                    <td>{dump.weight}gm</td>
                    <td>€{dump.cost}</td>
                    <td>{dump.updated_on}</td>
                    <td>
                      {/* <Button outline theme="primary" onClick={() => this.onDumpSelected(dump.dump_id)}>View Dump</Button> */}
                      <Button outline theme="primary" onClick={() => this.onUserSelected(dump.user_id)}>View User</Button>
                      <Button outline theme="success" onClick={() => this.onBinSelected(dump.bin_id)}>View Bin</Button>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </Row>
      );
    }
  }
}

export default DumpsList;