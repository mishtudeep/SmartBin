import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

import axios from 'axios';
import { BASE_URL } from "../utils/Constants";

class Bin extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      binId: -1,
      bin: null
    };

    this.onBinSelected = this.onBinSelected.bind(this);
  }

  onBinSelected(binId = 1) {
    this.setState({
      ...this.state, selectedBinId: binId, isBinSelected: true
    });
  }

  componentDidMount() {
    var href = window.location.href;
    var parts = href.split('/');

    var binId = parts[parts.length - 1];

    this.setState({
      ...this.state, binId
    })

    console.log(binId);

    axios.post(`${BASE_URL}get_bin_api`, { bin_id: binId }, null).then((response) => {
      var bin = response.data;
      this.setState({
        ...this.state, bin
      });
    }, (error) => {
      console.log("error", error)
    })
  }

  render() {
    if (this.state.bin == null) {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title="Loading..." subtitle="" className="text-sm-left" />
          </Row>
        </Container>
      );
    } else {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title={this.state.bin.house_name} subtitle="" className="text-sm-left" />
          </Row>
          <Row>
            <Col lg="12" sm="12" className="mb-4">
              <Card small style={{
                cursor: 'pointer'
              }} className="card-post card-post--aside card-post--1">
                <div
                  className="card-post__image"
                  style={{
                    backgroundImage: `url('${require("../images/content-management/1.jpeg")}')`,
                  }}
                >
                  <Badge
                    pill
                    className={`card-post__category bg-royal-blue`}
                  >
                    NEW
                  </Badge>
                </div>
                <CardBody>
                  <h5 className="card-title">
                    <span className="text-fiord-blue">
                      {this.state.bin.house_name}
                    </span>
                  </h5>
                  <p className="card-text d-inline-block mb-3">{this.state.bin.address_line_1}</p>
                  <p className="card-text mb-3">Dimension(in cm): {`${this.state.bin.height}x${this.state.bin.width}x${this.state.bin.length}`}</p>
                  <p className="card-text"> Current Weight: {this.state.bin.current_weight} kg ({this.state.bin.filled_percent}% filled)</p>
                  <p className="text-muted"> Capacity: {this.state.bin.capacity} kg</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title="Bin Stats" subtitle="" className="text-sm-left" />
          </Row>
          <Row>
            <table className="table mb-0">
              <thead className="bg-light">
                <tr>
                  <th scope="col" className="border-0">
                    #
                  </th>
                  <th scope="col" className="border-0">
                    Temperature
                  </th>
                  <th scope="col" className="border-0">
                    Humidity
                  </th>
                  {/* <th scope="col" className="border-0">
                    Weight
                  </th> */}
                  <th scope="col" className="border-0">
                    Gas Concentration
                  </th>
                  <th scope="col" className="border-0">
                    Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {
                  this.state.bin.stats.map((stat, idx) => (
                    <tr>
                      <td>{stat.stats_id}</td>
                      <td>{stat.temperature}</td>
                      <td>{stat.humidity}</td>
                      {/* <td>{stat.weight}gm</td> */}
                      <td>{stat.gas_concentration}</td>
                      <td>{stat.updated_on}</td>
                    </tr>
                  ))
                }
              </tbody>
            </table>
          </Row>
        </Container>
      );
    }
    
  }

}

export default Bin;