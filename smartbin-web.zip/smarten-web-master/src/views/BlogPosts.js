/* eslint jsx-a11y/anchor-is-valid: 0 */
import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge,
  Button
} from "shards-react";
import axios from "axios";
import { BASE_URL } from "../utils/Constants";

import PageTitle from "../components/common/PageTitle";

class BlogPosts extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // First list of posts.
      clients: null,
      selectedClientId: 1,
      isClientSelected: false
    };
    this.onClientSelected = this.onClientSelected.bind(this);
  }

  onClientSelected(clientId) {
    this.setState({
      ...this.state, selectedClientId: clientId, isClientSelected: true
    });
  }

  componentDidMount() {
    var userJson = localStorage.getItem("user");
    if (userJson != undefined && userJson != null) {
      var user = JSON.parse(userJson);

      var data = null;
      if (user.role == 'admin') {
        axios.post(`${BASE_URL}clients_api`, data, null).then((response) => {
          var data = response.data;
          this.setState({
            ...this.state, clients: data.clients
          })
        }, (error) => {

        }); 
      }
    }
  }

  render() {
    const {
      clients
    } = this.state;

    var user = localStorage.getItem("user");

    if (user == undefined || user == null) {
      return (<Redirect key="login" to={`/login`} />);
    } else if (this.state.isClientSelected || user.role == 'client') {
      return (<Redirect push key={`client#${this.state.selectedClientId}`} to={`/client/${this.state.selectedClientId}`} />);
    } else {
      if (this.state.clients == null) {
        return (
          <Container fluid className="main-content-container px-4">
            <Row noGutters className="page-header py-4">
              <PageTitle sm="4" title="Loading..." subtitle="" className="text-sm-left" />
            </Row>
          </Container>
);
      } else {
        return (
          <Container fluid className="main-content-container px-4">
            {/* Page Header */}
            <Row noGutters className="page-header py-4">
              <PageTitle sm="4" title="Clients" subtitle="" className="text-sm-left" />
            </Row>
            <Row>
              {clients.map((client, idx) => (
                <Col lg="6" sm="12" className="mb-4" key={idx}>
                  <Card small style={{ cursor: "pointer" }} className="card-post card-post--aside card-post--1" onClick={() => this.onClientSelected(client.client_id)}>
                    <div
                      className="card-post__image"
                      style={{
                        backgroundImage: `url('${require("../images/content-management/1.jpeg")}')`,
                      }}
                    >
                      <Badge
                        pill
                        className={`card-post__category bg-royal-blue`}
                      >
                        NEW
                  </Badge>
                    </div>
                    <CardBody>
                      <h5 className="card-title">
                        <span className="text-fiord-blue">
                          {client.client_name}
                        </span>
                      </h5>
                      <p className="card-text d-inline-block mb-3">{client.address_line_1}</p>
                      <p className="card-text mb-3">Phone: {client.primary_phone}</p>
                      <p className="text-muted"> Revenue: €{client.revenue}</p>
                    </CardBody>
                  </Card>
                </Col>
              ))}
            </Row>
          </Container>
        );
      }
      
    }
  }
}

export default BlogPosts;
