import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";


import axios from 'axios';
import { BASE_URL } from "../utils/Constants";

import PageTitle from "../components/common/PageTitle";

class User extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      userId: -1,
      user: null
    };
  }

  componentDidMount() {
    var href = window.location.href;
    var parts = href.split('/');

    var userId = parts[parts.length - 1];

    this.setState({
      ...this.state, userId
    })

    console.log(userId);

    axios.post(`${BASE_URL}get_user_api`, { user_id: userId }, null).then((response) => {
      var user = response.data;
      this.setState({
        ...this.state, user
      });
    }, (error) => {
      console.log("error", error)
    })
  }

  render() {
    if (this.state.user == null) {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title="Loading..." subtitle="" className="text-sm-left" />
          </Row>
        </Container>
      );
    } else {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title={this.state.user.first_name} subtitle="" className="text-sm-left" />
          </Row>
          <Row>
            <Col lg="12" sm="12" className="mb-4">
              <Card small style={{
                cursor: 'pointer'
              }} className="card-post card-post--aside card-post--1">
                <CardBody>
                  <h5 className="card-title">
                    <span className="text-fiord-blue">
                      {`${this.state.user.first_name} ${this.state.user.last_name}`}
                    </span>
                  </h5>
                  <p className="card-text d-inline-block mb-3">{this.state.user.address_line_1}</p>
                  <p className="card-text mb-3">Email: {this.state.user.email}</p>
                  <p className="text-muted">Balance: €{this.state.user.wallet_balance}</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      );
    }
  }
}

export default User;