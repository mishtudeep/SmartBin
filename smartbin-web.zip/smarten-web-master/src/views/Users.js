/* eslint jsx-a11y/anchor-is-valid: 0 */
import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";

import { ButtonGroup, Button } from "shards-react";

import PageTitle from "../components/common/PageTitle";
import UserList from "./UserList";
import BinsList from "./BinsList";
import DumpsList from "./DumpsList";

import axios from 'axios';
import { BASE_URL } from "../utils/Constants";

class Client extends React.Component {
  constructor(props) {
    super(props);

    var selectedItem = localStorage.getItem("selected_option");
    if (selectedItem == null || selectedItem == undefined) {
      selectedItem = { 'key': 'users', 'name': 'Users' };
    } else {
      selectedItem = JSON.parse(selectedItem);
    }

    this.state = {
      selectedItem: selectedItem,
      clientId : -1,
      client: {}
    };

    this.buttonItems = [
      { 'key': 'users', 'name': 'Users' },
      { 'key': 'bins', 'name': 'Bins' },
      { 'key': 'dumps', 'name': 'Dumps' }
    ];

    this.onUserSelected = this.onUserSelected.bind(this);
    this.onItemSelected = this.onItemSelected.bind(this);
  }

  onItemSelected(item) {
    localStorage.setItem("selected_option", JSON.stringify(item));
    this.setState({
      ...this.state, selectedItem: item
    });
  }

  onUserSelected(userId = 1) {
    this.setState({
      ...this.state, selectedUserId: userId, isUserSelected: true
    });
  }

  componentDidMount() {
    var href = window.location.href;
    var parts = href.split('/');

    var clientId = parts[parts.length - 1];

    this.setState({
      ...this.state, clientId
    })

    console.log(clientId);

    axios.post(`${BASE_URL}get_client_api`, { client_id: clientId }, null).then((response) => {
      var client = response.data;
      this.setState({
        ...this.state, client
      });
    }, (error) => {
        console.log("error", error)
    })
  }

  render() {
    var childComponent = null;
    if (this.state.selectedItem.key == 'users') {
      childComponent = <UserList clientId={this.state.clientId} data={this.state.client.users} />;
    } else if (this.state.selectedItem.key == 'bins') {
      childComponent = <BinsList clientId={this.state.clientId} data={this.state.client.bins}/>;
    } else if (this.state.selectedItem.key == 'dumps') {
      childComponent = <DumpsList clientId={this.state.clientId} data={this.state.client.dumps}/>;
    }

    if (this.state.client.client_name != undefined) {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="4" title={this.state.client.client_name} subtitle="" className="text-sm-left" />
          </Row>
          <Row noGutters className="page-header py-4">
            <ButtonGroup className="mb-3">
              {
                this.buttonItems.map((item) => (
                  <Button
                    theme={item.key == this.state.selectedItem.key ? "primary" : "white"}
                    onClick={() => this.onItemSelected(item)}
                  >
                    {item.name}
                  </Button>
                ))
              }
            </ButtonGroup>
          </Row>
          <Row noGutters className="page-header py-4">
            <PageTitle sm="4" title={this.state.selectedItem.name} subtitle="" className="text-sm-left" />
          </Row>
          {childComponent}
        </Container>
      );
    } else {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="4" title="Loading..." subtitle="" className="text-sm-left" />
          </Row>
        </Container>
      );
    }

    
  }
}

export default Client;
