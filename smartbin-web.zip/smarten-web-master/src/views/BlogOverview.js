import React, { Component } from "react";
import { Redirect } from 'react-router-dom';
import PropTypes, { object } from "prop-types";
import { Container, Row, Col } from "shards-react";

import PageTitle from "./../components/common/PageTitle";
import SmallStats from "./../components/common/SmallStats";
import UsersOverview from "./../components/blog/UsersOverview";
import UsersByDevice from "./../components/blog/UsersByDevice";
import NewDraft from "./../components/blog/NewDraft";
import Discussions from "./../components/blog/Discussions";
import TopReferrals from "./../components/common/TopReferrals";
import axios from "axios";
import { BASE_URL } from "../utils/Constants";

class BlogOverview extends Component {
  constructor(props) {
    super(props)
    this.state = {
      smallStats: [],
      redirect: false
    }
  }

  componentDidMount() {
    var user = localStorage.getItem("user");
    if (user == undefined || user == null) {
      this.setState({
        ...this.state, redirect: true
      });
    }

    var userJson = localStorage.getItem("user");
    if (userJson != undefined && userJson != null) {
      var user = JSON.parse(userJson);

      var data = null;
      if (user.role == 'client') {
        data = {"client_id": user.client_id}
      }

      axios.post(`${BASE_URL}dashboard_api`, data, null).then((response) => {
        var data = response.data;

        var finalData = [];
        data.map((d) => {
          var sd = {
            label: d.label,
            value: d.value
          };
          if (d.label == 'wastage') {
            sd.value = sd.value + " gm";
          } else if (d.label == 'revenue') {
            sd.value = "€ " +sd.value;
          }
          finalData.push(sd);
        });

        console.log("DATA:", finalData);

        this.setState({
          ...this.state, smallStats : finalData
        })
      }, (error) => {
          
      });
    }
  }

  render() {
    if (this.state.redirect) {
      return (
        <Redirect push key="login" to="/login" />
      );
    } else {
      return (
        <Container fluid className="main-content-container px-4">
          {/* Page Header */}
          <Row noGutters className="page-header py-4">
            <PageTitle title="Good Morning!" subtitle="Dashboard" className="text-sm-left mb-3" />
          </Row>

          {/* Small Stats Blocks */}
          <Row>
            {this.state.smallStats.map((stats, idx) => (
              <Col md="4" className="mb-4" key={idx} {...stats.attrs}>
                <SmallStats
                  id={`small-stats-${idx}`}
                  // variation="1"
                  // chartData={object}
                  // chartLabels={object}
                  label={stats.label}
                  value={stats.value}
                />
              </Col>
            ))}
          </Row>
        </Container>
      );
    }
  }
}

export default BlogOverview;
