import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

class Dump extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // First list of posts.
      PostsListOne:
      {
        backgroundImage: require("../images/content-management/4.jpeg"),
        category: "Business",
        categoryTheme: "warning",
        author: "John James",
        authorAvatar: require("../images/avatars/3.jpg"),
        title: "It so numerous if he may outlived disposal",
        body:
          "How but sons mrs lady when. Her especially are unpleasant out alteration continuing unreserved ready road market resolution...",
        date: "29 February 2019"
      },
      selectedDumpId: 1,
      isDumpSelected: false,
    };

    this.onDumpSelected = this.onDumpSelected.bind(this);
  }

  onDumpSelected(dumpId = 1) {
    this.setState({
      ...this.state, selectedDumpId: dumpId, isDumpSelected: true
    });
  }

  componentWillMount() {
    console.log(window.location.href);
  }

  render() {
    const {
      PostsListOne
    } = this.state;

    if (this.state.isDumpSelected) {
      return (
        <Redirect push key="dump#1" to="/dump/1" />
      )
    } else {
      return (
        <Container fluid className="main-content-container px-4">
          <Row noGutters className="page-header py-4">
            <PageTitle sm="12" title="Dummy Dump Name #1" subtitle="" className="text-sm-left" />
          </Row>
          <Row>
            <Col lg="12" sm="12" className="mb-4">
              <Card small style={{
                cursor: 'pointer'
              }} className="card-post card-post--aside card-post--1">
                <div
                  className="card-post__image"
                  style={{
                    backgroundImage: `url('${require("../images/content-management/1.jpeg")}')`,
                  }}
                >
                  <Badge
                    pill
                    className={`card-post__category bg-royal-blue`}
                  >
                    NEW
                  </Badge>
                </div>
                <CardBody>
                  <h5 className="card-title">
                    <span className="text-fiord-blue">
                      Dummy Dump Name #1
                  </span>
                  </h5>
                  <p className="card-text d-inline-block mb-3">Dummy dump address</p>
                  <p className="card-text mb-3">Dummy Phone number</p>
                  <p className="text-muted"> Revenue: 10</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      );
    }
  }
}

export default Dump;