/* eslint jsx-a11y/anchor-is-valid: 0 */
import { Redirect } from "react-router-dom";
import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  Badge,
  Form,
  Alert
} from "shards-react";
import axios from 'axios';
import { BASE_URL } from '../utils/Constants';


import { ButtonGroup, Button } from "shards-react";

import PageTitle from "../components/common/PageTitle";

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      selectedItem: { 'key': 'client', 'name': 'Client' },
      redirect: false,
      showAlert: false,
      alertMessage: ""
    };

    this.buttonItems = [
      { 'key': 'admin', 'name': 'Admin' },
      { 'key': 'client', 'name': 'Client' }
    ];

    this.onItemSelected = this.onItemSelected.bind(this);
    this.onEmailChange = this.onEmailChange.bind(this);
    this.onPasswordChange = this.onPasswordChange.bind(this);
    this.onLoginSubmitted = this.onLoginSubmitted.bind(this);
  }

  onItemSelected(item) {
    this.setState({
      ...this.state, selectedItem: item
    });
  }

  onLoginSubmitted() {
    if (this.state.email == "" || this.state.password == "") {
      console.log("email, password can not be empty");
    } else {
      axios.post(`${BASE_URL}${this.state.selectedItem.key}_login_api`, {
        'email': this.state.email,
        'password': this.state.password
      }, null).then((response) => {
        console.log("Login API response: " + response);
        if (response != null) {
          var data = response.data;
          if (data.message == 'success') {
            localStorage.setItem("user", JSON.stringify(data.data));
            this.setState({
              ...this.state, redirect: true
            })
          } else {
            this.setState({
              ...this.state, showAlert: true, alertMessage: 'Invalid login'
            })
            setTimeout(() => {
              this.setState({
                ...this.state, showAlert: false
              });
            }, 3000)
          }
        }
      }, (error) => {
          console.log("Login API error: " + error);
          this.setState({
            ...this.state, showAlert: true, alertMessage: 'Invalid login'
          })
          setTimeout(() => {
            this.setState({
              ...this.state, showAlert: false
            });
          }, 3000)
      });
    }
  }

  onHomeButtonClicked() {
    window.location.href = "http://binbillings.com";
  }

  onEmailChange(event) {
    this.setState({
      ...this.state, email: event.target.value
    })
  }

  onPasswordChange(event) {
    this.setState({
      ...this.state, password: event.target.value
    })
  }

  componentWillMount() {
    console.log(window.location.href);
  }

  render() {
    if (this.state.redirect) {
      return (
        <Redirect key="dashboard" to='/dashboard' />
      );
    } else {
      return (
        <div style={{
          backgroundImage: `url('${require("../images/content-management/hero_2.jpg")}')`,
          width: "100%",
          height: "100vh"
        }}>
          <Container fluid className="main-content-container px-4">
            {/* Page Header */}
            {
              this.state.showAlert ?
                <Alert className="mb-0" theme="danger">
                  {this.state.alertMessage}
                </Alert>
                :
                ''
            }
            <Row noGutters className="page-header py-4">
              <PageTitle sm="4" title="BinBillings Dashboard" subtitle="" className="text-sm-left" />
            </Row>
            <Row noGutters className="page-header py-4">
              <ButtonGroup className="mb-3">
                {
                  this.buttonItems.map((item) => (
                    <Button
                      theme={item.key == this.state.selectedItem.key ? "primary" : "white"}
                      onClick={() => this.onItemSelected(item)}
                    >
                      {item.name}
                    </Button>
                  ))
                }
              </ButtonGroup>
            </Row>
            {/* Second Row of Posts */}
            <Row>
              <Col lg="12" sm="12" className="mb-4" >
                <Card small className="card-post card-post--aside card-post--1" onClick={this.onUserSelected}>
                  <CardBody>
                    <h5 className="card-title">
                      <span className="text-fiord-blue">
                        {this.state.selectedItem.name} Login
                      </span>
                    </h5>

                    <Row form>
                      <Col md="6" className="form-group">
                        <label htmlFor="feEmailAddress">Email</label>
                        <input
                          id="feEmailAddress"
                          className="form-control"
                          type="email"
                          placeholder="Email"
                          onChange={this.onEmailChange}
                        />
                      </Col>
                      <Col md="6">
                        <label htmlFor="fePassword">Password</label>
                        <input
                          id="fePassword"
                          type="password"
                          className="form-control"
                          placeholder="Password"
                          onChange={this.onPasswordChange}
                        />
                      </Col>
                    </Row>
                    <Button onClick={() => this.onLoginSubmitted()}>Login</Button>
                    <Row style={{
                      marginTop: '20px'
                    }}>
                      <Col md="12">
                        <Button theme="success" onClick={() => this.onHomeButtonClicked()}>Go to Home</Button>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Container>
        </div>
      );
    }
  }
}

export default Login;
