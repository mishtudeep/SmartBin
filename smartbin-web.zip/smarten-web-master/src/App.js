import React from "react";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";

import { getRoutes } from "./routes";
import withTracker from "./withTracker";

import "bootstrap/dist/css/bootstrap.min.css";
import "./shards-dashboard/styles/shards-dashboards.1.1.0.min.css";

export default () => {
  var routes = getRoutes();
  console.log("routes: ", routes);

  return (
    <Router basename={process.env.REACT_APP_BASENAME || ""}>
      <div>
        {routes.map((route, index) => {
          console.log("app: ", route);
          if (route.redirect == true) {
            console.log("app: rendering");
            return (
              <Route
                path={route.path}
                exact={true}
                render={() => <Redirect key={route.to} to={`/${route.to}`} />}
              />
            );
          } else {
            console.log("app: componenting");
            return (
              <Route
                key={route.key}
                path={route.path}
                exact={false}
                component={props => {
                  return (
                    <route.layout {...props}>
                      <route.component {...props} />
                    </route.layout>
                  );
                }}
              />
            );
          }
        })}
      </div>
    </Router>
  )
};
