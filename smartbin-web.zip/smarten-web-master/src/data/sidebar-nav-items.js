export default function () {
  var userJson = localStorage.getItem('user');

  var clientItem = 'clients';
  if (userJson == undefined || userJson == null) {
    // do nothing
  } else {
    var user = JSON.parse(userJson);
    if (user == null) {
      // do nothing
    } else if (user.role == 'client') {
      clientItem = 'client/1';
    }
  }
  
  return [
    {
      title: "Dashboard",
      to: "/dashboard",
      htmlBefore: '<i class="material-icons">edit</i>',
      htmlAfter: ""
    },
    {
      title: "Clients",
      htmlBefore: '<i class="material-icons">vertical_split</i>',
      to: `/${clientItem}`,
    }
  ];
}
