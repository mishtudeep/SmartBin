<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Base extends CI_Controller
{
  function output_json($data, $code = 200)
  {
    $this->output
      ->set_content_type('application/json', 'utf-8')
      ->set_status_header($code)
      ->set_output(json_encode($data));
  }

  public function get_payload()
  {
    $payload = json_decode(file_get_contents('php://input'), true);
    return $payload;
  }

  function get_post_params($keys)
  {
    $param_values = array();
    foreach ($keys as $key) {
      $param_values[$key] = $this->input->post($key);
    }
    return $param_values;
  }

  public function index()
  {
    $this->output_json(array('message' => 'no api end point found'), 403);
  }
}
