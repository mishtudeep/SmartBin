<?php
defined('BASEPATH') or exit('No direct script access allowed');
include "Base.php";
class Api extends Base
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model(array(
      'adminmodel'
    ));
  }

  public function index()
  {
    $this->output_json(array('message' => 'no api end point found'));
  }

  function create_admin()
  {
    $keys = ['client_id', 'first_name', 'last_name', 'email', 'phone', 'password'];
    $param_values = $this->get_post_params($keys);
    $param_values['profile_pic'] = $this->upload_file('profile_pic');
    $admin = $this->adminmodel->create_admin(
      $param_values['client_id'],
      $param_values['first_name'],
      $param_values['last_name'],
      $param_values['email'],
      $param_values['phone'],
      $param_values['profile_pic'],
      $param_values['password']
    );
    if ($admin == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $admin));
    }
  }

  function update_admin()
  {
    $keys = ['admin_id', 'first_name', 'last_name', 'email', 'phone', 'password'];
    $param_values = $this->get_post_params($keys);
    $param_values['profile_pic'] = $this->upload_file('profile_pic');
    $admin = $this->adminmodel->update_admin(
      $param_values['admin_id'],
      $param_values['first_name'],
      $param_values['last_name'],
      $param_values['email'],
      $param_values['phone'],
      $param_values['profile_pic'],
      $param_values['password']
    );
    if ($admin == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $admin));
    }
  }

  function create_client()
  {
    $keys = ['client_name', 'address_line_1', 'address_line_2', 'primary_email', 'primary_phone', 'emergency_contact'];
    $param_values = $this->get_post_params($keys);
    $param_values['logo_image'] = $this->upload_file('logo_image');
    $client = $this->adminmodel->create_client(
      $param_values['client_name'],
      $param_values['address_line_1'],
      $param_values['address_line_2'],
      $param_values['primary_email'],
      $param_values['primary_phone'],
      $param_values['emergency_contact'],
      $param_values['logo_image']
    );
    if ($client == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $client));
    }
  }

  function update_client()
  {
    $keys = ['client_id', 'client_name', 'address_line_1', 'address_line_2', 'primary_email', 'primary_phone', 'emergency_contact'];
    $param_values = $this->get_post_params($keys);
    $param_values['logo_image'] = $this->upload_file('logo_image');
    $client = $this->adminmodel->create_client(
      $param_values['client_id'],
      $param_values['client_name'],
      $param_values['address_line_1'],
      $param_values['address_line_2'],
      $param_values['primary_email'],
      $param_values['primary_phone'],
      $param_values['emergency_contact'],
      $param_values['logo_image']
    );
    if ($client == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $client));
    }
  }

  function admin_login()
  {
    $keys = ['email', 'password'];
    $param_values = $this->get_post_params($keys);
    $admin_data = $this->adminmodel->admin_login($param_values['email'], $param_values['password']);
    if ($admin_data == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $admin_data));
    }
  }

  function user_registration()
  {
    $keys = ['email', 'password', 'name'];
    $param_values = $this->get_post_params($keys);
    $user_data = $this->adminmodel->user_registration($param_values['email'], $param_values['password'], $param_values['name']);
    mail($param_values['email'],"OTP Verification from BinBillings", "Your OTP is : 123456");
    if ($user_data == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $user_data));
    }
   }

   function verify_otp() {
    $keys = ['user_id', 'otp'];
    $param_values = $this->get_post_params($keys);
    $user_data = $this->adminmodel->get_user_by_id($param_values['user_id']);
    if ($user_data == null || $param_values['otp'] != '123456') {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $user_data));
    }
   }


  function user_login()
  {
    $keys = ['email', 'password'];
    $param_values = $this->get_post_params($keys);
    $user_data = $this->adminmodel->user_login($param_values['email'], $param_values['password']);
    if ($user_data == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'invalid credentials'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $user_data));
    }
  }

  function get_bins_by_location()
  {
    $keys = ['user_id', 'client_id', 'lat', 'lng'];
    $param_values = $this->get_post_params($keys);
    $bins = $this->adminmodel->get_bins_by_location($param_values['client_id'], $param_values['lat'], $param_values['lng']);
    if ($bins == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $bins));
    }
  }

  function start_dumping() {
    $keys = ['user_id', 'bin_id'];
    $param_values = $this->get_post_params($keys);
    $dumping_id = $this->adminmodel->start_dumping($param_values['user_id'], $param_values['bin_id']);
    if ($dumping_id == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $dumping_id));
    }
  }

  function stop_dumping() {
    $keys = ['dump_id'];
    $param_values = $this->get_post_params($keys);
    $dumping_id = $this->adminmodel->stop_dumping($param_values['dump_id']);
    if ($dumping_id == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $dumping_id));
    }
  }

  function get_dump() {
    $keys = ['dump_id'];
    $param_values = $this->get_post_params($keys);
    $dump = $this->adminmodel->get_dump($param_values['dump_id']);
    if ($dump == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $dump));
    }
  }

  function dump_history() {
    $keys = ['user_id'];
    $param_values = $this->get_post_params($keys);
    $dump = $this->adminmodel->get_dumps($param_values['user_id']);
    if ($dump == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $dump));
    }
  }

  function add_balance() {
    $keys = ['user_id', 'amount'];
    $param_values = $this->get_post_params($keys);
    $user = $this->adminmodel->add_balance($param_values['user_id'], $param_values['amount']);
    if ($user == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $user));
    }
  }

  function transaction_history() {
    $keys = ['user_id'];
    $param_values = $this->get_post_params($keys);
    $transactions = $this->adminmodel->get_transaction_history($param_values['user_id']);
    if ($transactions == null) {
      $this->output_json(array('message' => 'error', 'desc' => 'no bins found in the location'), 400);
    } else {
      $this->output_json(array('message' => 'success', 'desc' => 'success', 'data' => $transactions));
    }
  }

  function ack_dump() {
    $keys = ['ID', 'Weight', 'Action'];
    $param_values = $this->get_post_params($keys);
    echo $this->adminmodel->ack_dump($param_values['ID'], $param_values['Weight'], $param_values['Action']);
  }

  function hearbeat_dump() {
    $keys = ['ID', 'Gas', 'Temperature', 'Humidity'];
    $param_values = $this->get_post_params($keys);
    echo $this->adminmodel->hearbeat_dump($param_values['ID'], $param_values['Gas'], $param_values['Temperature'], $param_values['Humidity']);
  }

  function test_mqtt($action) {
    $this->adminmodel->test_mqtt($action);
  }

  function user_update()
  { }

  function user_change_password()
  { }

  function user_add_card()
  { }

  function user_get_profile()
  { }

  function user_get_cards()
  { }
}
