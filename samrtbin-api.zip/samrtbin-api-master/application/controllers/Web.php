<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Web extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->library(array(
			'session'
		));
		$this->load->model(array(
			'webmodel'
		));
		$this->load->helper('url');
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Headers: *');
		header("Access-Control-Allow-Methods: GET, OPTIONS, POST");
	}

	public function index()
	{
		if ($this->session->userdata('is_login') == true) {
			redirect('/web/home');
		} else {
			redirect('/web/choose');
		}
	}

	public function choose()
	{
		if ($this->session->userdata('is_login') == true) {
			redirect('/web/home');
		} else {
			$this->load->view('choose');
		}
	}

	public function client_login()
	{
		if ($this->session->userdata('is_login') == true) {
			redirect('/web/home');
		} else {
			$this->load->view('client_login');
		}
	}

	public function admin_login()
	{
		if ($this->session->userdata('is_login') == true) {
			redirect('/web/home');
		} else {
			$this->load->view('admin_login');
		}
	}

	public function get_payload()
	{
		$payload = json_decode(file_get_contents('php://input'), true);
		return $payload;
	}


	public function login_api()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$payload = $this->get_payload();
			$email = $payload['email'];
			$password = $payload['password'];

			$user = $this->webmodel->login($email, $password);
			$message = "error";
			if ($user !=  null) {
				$message = "success";
			}

			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_status_header(200)
				->set_output(json_encode(array('message' => $message, 'data' => $user)));
		} else {
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_status_header(200)
				->set_output(json_encode(array()));
		}


		// if ($user != null) {
		// 	$this->session->set_userdata('user', $user);
		// 	$this->session->set_userdata('role', 'client');
		// 	$this->session->set_userdata('is_login', true);
		// 	redirect('/web/home');
		// } else {
		// 	redirect('/web/client_login');
		// }
	}

	public function client_login_api()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->webmodel->client_login($email, $password);

		if ($user != null) {
			$this->session->set_userdata('user', $user);
			$this->session->set_userdata('role', 'client');
			$this->session->set_userdata('is_login', true);
			redirect('/web/home');
		} else {
			redirect('/web/client_login');
		}
	}

	public function admin_login_api()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		if ($email == 'admin@binbillings.com' && $password == 'admin1234') {
			$this->session->set_userdata('user', $user);
			$this->session->set_userdata('role', 'admin');
			$this->session->set_userdata('is_login', true);
			redirect('/web/home');
		} else {
			redirect('/web/admin_login');
		}
	}

	private function pre_check_session()
	{
		if ($this->session->userdata('is_login') == false) {
			redirect('/web/choose');
		}
	}

	public function home()
	{
		$this->pre_check_session();
		$role = $this->session->userdata('role');
		$data = array();
		$data['role'] = $role;
		if ($role == 'client') {
			$user = $this->session->userdata('user');
			$clientid = $user['client_id'];

			// load client data
			$data['users'] = $this->webmodel->get_total_users($clientid);
			$data['dumps'] = $this->webmodel->get_total_dumps($clientid);
			$data['bins'] = $this->webmodel->get_total_bins($clientid);
			$data['dumps_kg'] = $this->webmodel->get_total_dumps_kg($clientid);
			$data['revenue'] = $this->webmodel->get_total_revenue($clientid);
		} else {
			$data['users'] = $this->webmodel->get_total_users();
			$data['clients'] = $this->webmodel->get_total_clients();
			$data['dumps'] = $this->webmodel->get_total_dumps();
			$data['bins'] = $this->webmodel->get_total_bins();
			$data['dumps_kg'] = $this->webmodel->get_total_dumps_kg();
			$data['revenue'] = $this->webmodel->get_total_revenue();
		}

		$this->load->view('home', $data);
	}

	public function dashboard_api(){
		$data = array();
		$data['users'] = $this->webmodel->get_total_users();
		$data['clients'] = $this->webmodel->get_total_clients();
		$data['dumps'] = $this->webmodel->get_total_dumps();
		$data['bins'] = $this->webmodel->get_total_bins();
		$data['dumps_kg'] = $this->webmodel->get_total_dumps_kg();
		$data['revenue'] = $this->webmodel->get_total_revenue();
		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_status_header(200)
			->set_output(json_encode($data));
	}

	public function clients() 
	{
		$this->pre_check_session();
		$data = array();
		$data['role'] = $this->session->userdata('role');
		if ($data['role'] == 'admin') {
			$data['clients'] = $this->webmodel->get_clients();
		} else {
			$user = $this->session->userdata('user');
			$data['clients'] = $this->webmodel->get_clients($user['client_id']);
		}
		$this->load->view('clients', $data);
	}

	public function clients_api() {
		$data = array();
		$data['clients'] = $this->webmodel->get_clients();
		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_status_header(200)
			->set_output(json_encode($data));
	}

	public function client($clientid) {
		$this->pre_check_session();
		$data = array();
		$data['client'] = $this->webmodel->get_client($clientid);
		$this->load->view('client', $data);
	}

	public function add_client()
	{
		echo "client addition form will come. not supported yet";
	}

	public function bins()
	{
		$this->pre_check_session();
		$data = array();
		$data['role'] = $this->session->userdata('role');
		if ($data['role'] == 'admin') {
			$data['bins'] = $this->webmodel->get_bins();
		} else {
			$user = $this->session->userdata('user');
			$data['bins'] = $this->webmodel->get_bins($user['client_id']);
		}
		$this->load->view('bins', $data);
	}

	public function bins_api() {
		$data = array();
		$data['bins'] = $this->webmodel->get_bins();
		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_status_header(200)
			->set_output(json_encode($data));
	}

	public function bin($binid) {
		$this->pre_check_session();
		$data = array();
		$data['bin'] = $this->webmodel->get_bin($binid);
		$this->load->view('bin', $data);
	}

	public function add_bin()
	{
		echo "bin addition form will come. not supported yet";
	}

	public function users()
	{
		$this->pre_check_session();
		$data = array();
		$data['role'] = $this->session->userdata('role');
		if ($data['role'] == 'admin') {
			$data['users'] = $this->webmodel->get_users();
		} else {
			$user = $this->session->userdata('user');
			$data['users'] = $this->webmodel->get_users($user['client_id']);
		}
		$this->load->view('users', $data);
	}

	public function users_api() {
		$data = array();
		$data['users'] = $this->webmodel->get_users();
		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_status_header(200)
			->set_output(json_encode($data));
	}

	public function user($userid)
	{
		$this->pre_check_session();
		$data = array();
		$data['user'] = $this->webmodel->get_user($userid);
		$this->load->view('user', $data);
	}

	public function add_user()
	{
		echo "user addition form will come. not supported yet";
	}

	public function dumps()
	{
		$this->pre_check_session();
		$data = array();
		$data['role'] = $this->session->userdata('role');
		if ($data['role'] == 'admin') {
			$data['dumps'] = $this->webmodel->get_dumps();
		} else {
			$user = $this->session->userdata('user');
			$data['dumps'] = $this->webmodel->get_dumps($user['client_id']);
		}
		$this->load->view('dumps', $data);
	}

	public function dumps_api()
	{
		$data = array();
		$data['dumps'] = $this->webmodel->get_dumps();
		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_status_header(200)
			->set_output(json_encode($data));
	}

	public function dump($dumpid) {
		$this->pre_check_session();
		$data = array();
		$data['dump'] = $this->webmodel->get_dump($dumpid);
		$this->load->view('dump', $data);
	}

	public function logout()
	{
		$this->session->set_userdata('user', null);
		$this->session->set_userdata('is_login', false);
		redirect('/web/choose');
	}
}
