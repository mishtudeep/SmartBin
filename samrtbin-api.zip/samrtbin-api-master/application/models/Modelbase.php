<?php
class Modelbase extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->database();
  }

  public function get_table_count($tablename, $condition = '')
  {
    $this->db->select('*');
    if ($condition != '') {
      $this->db->where($condition);
    }
    $this->db->from($tablename);
    $query = $this->db->get();
    return $query->num_rows();
  }

  public function get_table_data($tablename, $return_type = 'row', $fields = '*', $condition = '', $offset = 0, $limit = 20, $debug = 0)
  {
    $this->db->select($fields);
    $this->db->from($tablename);
    if ($condition != '') {
      $this->db->where($condition);
    }
    $this->db->offset($offset);
    $this->db->limit($limit);
    $this->db->order_by('updated_on', 'DESC');
    $query = $this->db->get();
    if ($debug == '1') {
      echo $this->db->last_query();
      die();
    }
    if ($query->num_rows() > 0) {
      if ($return_type == 'row') {
        return $query->row_array();
      } else {
        return $query->result_array();
      }
    } else {
      return NULL;
    }
  }

  public function insert_table_data($tablename, $data)
  {
    $this->db->insert($tablename, $data);
    return $this->db->insert_id();
  }

  public function update_table_data($tablename, $value, $condition)
  {
    $this->db->where($condition);
    $this->db->update($tablename, $value);
  }

  public function delete_table_data($tablename, $condition)
  {
    $this->db->where($condition);
    $this->db->delete($tablename);
  }

  public function get_primary_key_name($table_name)
  {
    switch ($table_name) {
      case 'user':
        return 'user_id';
      default:
        return '';
    }
  }
}
