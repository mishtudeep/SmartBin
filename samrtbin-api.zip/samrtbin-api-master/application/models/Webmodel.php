<?php
include "Modelbase.php";
class Webmodel extends Modelbase
{
  function client_login($email,  $password)
  {
    return $this->get_table_data('bin_client_admin', 'row', '*', array('email' => $email, 'password' => $password));
  }

  function login($email,  $password)
  {
    if ($email == 'admin@binbillings.com' && $password == 'admin1234') {
      $user = array();
      $user['user_id'] = '0';
      $user['role'] = 'admin';
      return $user;
    } else {
      $user = $this->get_table_data('bin_client_admin', 'row', '*', array('email' => $email, 'password' => $password));
      if ($user != null) {
        $user['role'] = 'client';
      }
      return $user;
    }
  }

  public function get_total_users($clientid = 0)
  {
    $condition = '';
    if ($clientid != 0) {
      $condition = array('client_id' => $clientid);
    }
    return $this->get_table_count('bin_user', $condition);
  }

  public function get_total_clients()
  {
    return $this->get_table_count('bin_client');
  }
  
  public function get_total_dumps($clientid = 0)
  {
    if ($clientid == 0) {
      $result = $this->db->query("SELECT COUNT(*) AS c FROM bin_dumps")->result_array();
      return (int) $result[0]["c"];
    } else {
      $result = $this->db->query("SELECT COUNT(*) AS c FROM bin_dumps WHERE user_id IN (SELECT user_id FROM bin_user WHERE client_id = $clientid)")->result_array();
      return $result[0]["c"];
    }
  }

  public function get_total_bins($clientid = 0)
  {
    $condition = '';
    if ($clientid != 0) {
      $condition = array('client_id' => $clientid);
    }
    return $this->get_table_count('bin_dustbin', $condition);
  }

  public function get_total_dumps_kg($clientid = 0)
  {
    if ($clientid == 0) {
      $result = $this->db->query("SELECT SUM(weight) AS c FROM bin_dumps")->result_array();
      $weight = $result[0]["c"];
      if ($weight == null) {
        $weight = 0;
      }
      return $weight;
    } else {
      $result = $this->db->query("SELECT SUM(weight) AS c FROM bin_dumps WHERE user_id IN (SELECT user_id FROM bin_user WHERE client_id = $clientid)")->result_array();
      $weight = $result[0]["c"];
      if ($weight == null) {
        $weight = 0;
      }
      return $weight;
    }
  }

  public function get_total_revenue($clientid = 0)
  {
    if ($clientid == 0) {
      $result = $this->db->query("SELECT SUM(cost) AS c FROM bin_dumps")->result_array();
      $weight = $result[0]["c"];
      if ($weight == null) {
        $weight = 0;
      }
      return $weight;
    } else {
      $result = $this->db->query("SELECT SUM(cost) AS c FROM bin_dumps WHERE user_id IN (SELECT user_id FROM bin_user WHERE client_id = $clientid)")->result_array();
      $weight = $result[0]["c"];
      if ($weight == null) {
        $weight = 0;
      }
      return $weight;
    }
  }

  public function get_clients($clientid = 0) 
  {
    $bins = $this->get_table_data('bin_client', 'array', '*');
    if ($bins == null) {
      $bins = array();
    }
    return $bins;
  }

  public function get_client($clientid) {
    return array(
      'client_id' => "1",
      'name' => 'Dummy Name',
      'address' => 'Dummy Address',
      'revenue' => 'Dummy Revenue'
    );
  }

  public function get_bins($clientid = 0) {
    $condition = '';
    if ($clientid != 0) {
      $condition = array('client_id' => $clientid);
    }
    $bins = $this->get_table_data('bin_dustbin', 'array', '*', $condition);
    if ($bins == null) {
      $bins = array();
    }
    return $bins;
  }

  public function get_bin($binid) {
    return array(
      'bin_id' => "1",
      'client_id' => "1",
      'name' => 'Dummy Name',
      'address' => 'Dummy Address',
      'revenue' => 'Dummy Revenue'
    );
  }

  public function get_users($clientid = 0) {
    $condition = '';
    if ($clientid != 0) {
      $condition = array('client_id' => $clientid);
    }
    $users = $this->get_table_data('bin_user', 'array', '*', $condition);
    if ($users == null) {
      $users = array();
    }
    return $users;
  }

  public function get_user($userid) {
    return array(
      'user_id' => "1",
      'client_id' => "1",
      'name' => 'Dummy Name',
      'address' => 'Dummy Address'
    );
  }

  public function get_dumps($clientid = 0) {
    if ($clientid == 0) {
      $query = $this->db->query("SELECT * FROM bin_dumps")->result_array();
      if ($query == null) {
        $query = array();
      }
      return $query;
    } else {
      $query = $this->db->query("SELECT * FROM bin_dumps WHERE user_id IN (SELECT user_id FROM bin_user WHERE client_id = $clientid)")->result_array();
      if ($query == null) {
        $query = array();
      }
      return $query;
    }
  }

  public function get_dump($dumpid) {
    return array(
      'dump_id' => "1",
      'bin_id' => '1',
      'user_id' => '1',
      'revenue' => 30,
      'weight' => 20,
      'time' => '2019-09-09 09:09:09'
    );
  }
}
