<?php

include "Modelbase.php";

class Adminmodel extends Modelbase
{

  function create_client_and_admin(
    // client related params
    $client_name,
    $address_line_1,
    $address_line_2,
    $primary_email,
    $primary_phone,
    $emergency_contact,
    $logo_image,
    // admin related params
    $first_name,
    $last_name,
    $email,
    $phone,
    $profile_pic,
    $password
  ) {
    $client = $this->create_client(
      $client_name,
      $address_line_1,
      $address_line_2,
      $primary_email,
      $primary_phone,
      $emergency_contact,
      $logo_image
    );

    $admin = $this->create_admin(
      $client['client_id'],
      $first_name,
      $last_name,
      $email,
      $phone,
      $profile_pic,
      $password
    );

    return array('client' => $client, 'admin' => $admin);
  }

  function create_client(
    $client_name,
    $address_line_1,
    $address_line_2,
    $primary_email,
    $primary_phone,
    $emergency_contact,
    $logo_image
  ) {
    $client_id = $this->insert_table_data('bin_client', array(
      'client_name' => $client_name,
      'address_line_1' => $address_line_1,
      'address_line_2' => $address_line_2,
      'primary_email' => $primary_email,
      'primary_phone' => $primary_phone,
      'emergency_contact' => $emergency_contact,
      'logo_image' => $logo_image
    ));

    return $this->get_client_by_id($client_id);
  }

  function update_client(
    $client_id,
    $client_name,
    $address_line_1,
    $address_line_2,
    $primary_email,
    $primary_phone,
    $emergency_contact,
    $logo_image
  ) {
    $this->update_table_data(
      'bin_client',
      array(
        'client_name' => $client_name,
        'address_line_1' => $address_line_1,
        'address_line_2' => $address_line_2,
        'primary_email' => $primary_email,
        'primary_phone' => $primary_phone,
        'emergency_contact' => $emergency_contact,
        'logo_image' => $logo_image
      ),
      array(
        'client_id' => $client_id
      )
    );

    return $this->get_client_by_id($client_id);
  }

  function create_admin(
    $client_id,
    $first_name,
    $last_name,
    $email,
    $phone,
    $profile_pic,
    $password
  ) {
    $admin_id = $this->insert_table_data(
      'bin_client_admin',
      array(
        'client_id' => $client_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'phone' => $phone,
        'profile_pic' => $profile_pic,
        'password' => $password
      )
    );

    return $this->get_admin_by_admin_id($admin_id);
  }

  function update_admin(
    $admin_id,
    $first_name,
    $last_name,
    $email,
    $phone,
    $profile_pic,
    $password
  ) {
    $this->update_table_data(
      'bin_client_admin',
      array(
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'phone' => $phone,
        'profile_pic' => $profile_pic,
        'password' => $password
      ),
      array(
        'admin_id' => $admin_id
      )
    );

    return $this->get_admin_by_admin_id($admin_id);
  }

  function admin_login(
    $email,
    $password
  ) {
    $admin = $this->get_table_data(
      'bin_client_admin',
      'row',
      '*',
      array('email' => $email, 'password' => $password)
    );

    if ($admin != NULL) { }
  }

  function get_admin_by_admin_id($admin_id)
  {
    $admin = $this->get_table_data(
      'bin_client_admin',
      'row',
      '*',
      array('admin_id' => $admin_id)
    );

    $admin['client'] = $this->get_client_by_id($admin['client_id']);

    unset($admin['client_id']);
    unset($admin['password']);

    return $admin;
  }

  function get_client_by_id($client_id)
  {
    return $this->get_table_data(
      'bin_client',
      'row',
      '*',
      array('client_id' => $client_id)
    );
  }

  function get_user_by_id($user_id) {
    $user = $this->get_table_data(
      'bin_user',
      'row',
      '*',
      array('user_id' => $user_id)
    );
    if ($user == null) {
      return null;
    } else {
      $user['client'] = $this->get_client_by_id($user['client_id']);
      unset($user['password']);
      unset($user['client_id']);
      return $user;
    }
  }

  /* 
  user login using email and password
  */
  function user_login($email, $password) {
    $user = $this->get_table_data(
      'bin_user',
      'row',
      '*',
      array('email' => $email, 'password' => $password)
    );

    if ($user != NULL) { 
      $user['client'] = $this->get_client_by_id($user['client_id']);
      unset($user['password']);
      unset($user['client_id']);
      return $user;
    } else {
      return null;
    }
  }

  /* 
  user registration using email and password
  */
  function user_registration($email, $password, $name)
  {
    $user = $this->get_table_data(
      'bin_user',
      'row',
      '*',
      array('email' => $email)
    );

    if ($user == NULL) {
      $user_id = $this->insert_table_data(
        'bin_user', 
        array(
          'email' => $email,
          'password' => $password,
          'first_name' => $name,
          'client_id' => 1
        )
      );
      return $this->get_user_by_id($user_id);
    } else {
      return null;
    }
  }

  /* 
  get bins by location
  */
  function get_bins_by_location($clientid, $lat, $lng) {
    return $this->get_table_data('bin_dustbin', 'array', '*', array('client_id' => $clientid));
  }

  function get_bin_by_id($bin_id) {
    return $this->get_table_data('bin_dustbin', 'row', '*', array('bin_id' => $bin_id));
  }

  /* 
  start dumping
  */
  function start_dumping($user_id, $bin_id) {
    $dump_id = $this->insert_table_data('bin_dumps', array('bin_id' => $bin_id, 'user_id' => $user_id, 'start_time' => date('Y-m-d H:i:s')));
		$msg = array("action" => "1", "ID" => $dump_id);
		$server_ip = "3.16.200.142";
    $command = "mosquitto_pub -h " . $server_ip . " -t open/".$bin_id." -m \"" . str_replace("\"", "\\\"", json_encode($msg)) . "\"";
    // echo $command; die;
		exec($command);
		return $dump_id;
  }

  function test_mqtt($action, $bin_id=1) {
    if ($action == 'open') {
      $msg = array("action" => "1", "ID" => "1");
    } else {
      $msg = array("action" => "0", "ID" => "1");
    }
    // $server = "localhost";     // change if necessary
    // $port = 1883;              // change if necessary
    // $client_id = "phpMQTT-publisher";
    // $mqtt = new phpMQTT($server, $port, $client_id);
    // if ($mqtt->connect(true, NULL)) {
    //   $mqtt->publish("open/".$bin_id, json_encode($msg), 0);
	  //   $mqtt->close();
    // }
  }

  function stop_dumping($dump_id) {
    $this->update_table_data('bin_dumps', array('ending_time' => date('Y-m-d H:i:s')), array('dump_id' => $dump_id));
    $dump = $this->get_dump($dump_id);
		$msg = array("action" => "0", "ID" => $dump_id);
		$server_ip = "3.16.200.142";
    $command = "mosquitto_pub -h " . $server_ip . " -t open/".$dump['bin_id']." -m \"" . str_replace("\"", "\\\"", json_encode($msg)) . "\"";
    // echo $command; die;
		exec($command);
    return $dump;
  }
  
  /* 
  get dump
  */
  function get_dump($dump_id) {
    $dump = $this->get_table_data('bin_dumps', 'row', '*', array('dump_id' => $dump_id));
    if ($dump == null) {
      return null;
    } else {
      $dump['user'] = $this->get_user_by_id($dump['user_id']);
      $dump['bin'] = $this->get_bin_by_id($dump['bin_id']);
      $dump['currency'] = '€';
      $dump_transaction_map = $this->get_table_data('bin_dump_transaction_map', 'row', '*', array('dump_id' => $dump_id));
      $dump['transaction_map'] = $dump_transaction_map;
      $dump['transaction'] = $this->get_table_data('bin_transaction', 'row', '*', array('transaction_id' => $dump_transaction_map['transaction_id']));
      return $dump;
    }
  }

  function get_dumps($user_id) {
    $dump = $this->get_table_data('bin_dumps', 'array', '*', array('user_id' => $user_id));
    if ($dump == null) {
      return null;
    } else {
      $result = array();
      foreach($dump as $d) {
        $result[] = $this->get_dump($d['dump_id']);
      }
      return $result;
    }
  }

  function add_balance($user_id, $amount) {
    $user = $this->get_user_by_id($user_id);
    if ($user == null) {
      return $user;
    } else {
      $balance = $user['wallet_balance'];
      $balance += $amount;
      $this->update_table_data('bin_user', array('wallet_balance' => $balance), array('user_id' => $user_id));
      $transaction_id = $this->insert_table_data(
        'bin_transaction',
        array(
          'user_id' => $user_id, 
          'transaction_token' => 'some_token', 
          'amount' => $amount, 
          'status' => 'success', 
          'type' => 'credit'
        )
      );
      $user['wallet_balance'] = $balance;
      return $user;
    }
  } 

  function get_transaction_history($user_id) {
    return $this->get_table_data('bin_transaction', 'array', '*', array('user_id' => $user_id));
	}
	
	function ack_dump($dump_id, $weight, $action) {
		if ($action == '1') {
			// store the weight
			$this->update_table_data(
				'bin_dumps',
				array('starting_weight' => $weight),
				array('dump_id' => $dump_id)
			);
			return "OK";
		} else {
			// get dump
			$dump = $this->get_dump($dump_id);
			if ($dump != null) {
				// calculate weight
				$starting_weight = $dump['starting_weight'];
				$weight_diff = $weight - $starting_weight;
				// calculate cost
				$cost = $weight_diff;
				// store ending weight, weight, cost in bin_dumps
				$this->update_table_data(
					'bin_dumps',
					array(
						'ending_weight' => $weight,
						'weight' => $weight_diff,
						'cost' => $cost
					),
					array('dump_id' => $dump_id)
				);
				// create transaction of debit for user (from dump)
				$this->insert_table_data(
					'bin_transaction',
					array(
						'user_id' => $dump['user_id'],
						'transaction_token' => "#".$dump_id."_trans_token",
						'amount' => $cost,
						'status' => 'success',
						'type' => 'debit'
					)
					);
				// update user balance
				$user = $this->get_user_by_id($dump['user_id']);
				$balance = $user['wallet_balance'] - $cost;
				$this->update_table_data(
					'bin_user',
					array('wallet_balance' => $balance),
					array('user_id' => $dump['user_id'])
				);
			}
			return "OK";
		}
		return "NOT OK";
	}

	function hearbeat_dump($bin_id, $gas, $temp, $humidity) {
		$this->insert_table_data(
			'bin_dustbin_stats',
			array(
				'bin_id' => $bin_id,
				'gas_concentration' => $gas,
				'temperature' => $temp,
				'humidity' => $humidity
			)
		);
		return "OK";
	}
}
