<?php
include "Modelbase.php";
class Datamodel extends Modelbase
{
  function insert($table_name, $data)
  {
    if (is_array($data)) {
      $output = array();

      foreach ($data as $d) {
        $output[] = $this->insert_table_data($table_name, $d);
      }
      return $output;
    } else if (is_object($data)) {
      return $this->insert_table_data($table_name, $data);
    } else {
      return null;
    }
  }
}
