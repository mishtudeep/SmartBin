<?php
include "base_view.php";
?>
<center>
    <table width="80%">
    <tr>
        <td>
            <h2>
                Total Users: <?php echo $users; ?>
            </h2>
        </td>
    </tr>
    
    <?php 
    if ($role == 'admin') {
    ?>
    <tr>
        <td>
            <h2>
                Total Clients: <?php echo $clients; ?>
            </h2>
        </td>
    </tr>
    <?php
    }
    ?>
    <tr>
        <td>
            <h2>
                Total Dumps: <?php echo $dumps; ?>
            </h2>
        </td>
    </tr>
    <tr>
        <td>
        <h2>
            Total Bins: <?php echo $bins; ?>
            </h2>
        </td>
    </tr>
    <tr>
        <td>
        <h2>
                Total Dumps (in KG): <?php echo $dumps_kg; ?>
                </h2>
        </td>
    </tr>
    <tr>
        <td>
        <h2>
                Total Revenue: <?php echo $revenue; ?>
                </h2>
        </td>
    </tr>
</table>
</center>
