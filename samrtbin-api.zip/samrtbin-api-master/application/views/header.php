<a href="/home">Home</a>
<a href="/home">Home</a>