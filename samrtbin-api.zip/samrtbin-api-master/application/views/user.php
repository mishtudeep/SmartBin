<?php
include "base_view.php";
?>

<center>
  <?php
  echo $user['name'];
  ?>
  <br><br>
</center>