<?php
include "base_view.php";
?>

<center>
  <?php
  echo $dump['dump_id'];
  ?>
  <br><br>
</center>