<?php
include "base_view.php";
?>

<center>
    <?php
        echo $client['name'];
    ?>
    <br><br>
</center>
