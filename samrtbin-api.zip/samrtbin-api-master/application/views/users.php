<?php
include "base_view.php";
?>

<center>
  <table width="80%">
    <tr>
      <td>
        <h2>Users</h2>
      </td>
      <td>
        <a href="<?php echo base_url() ?>index.php/web/add_user">Add User</a>
      </td>
    </tr>
  </table>
  <table width="80%" border="1px">
    <thead>
      <td><strong>User ID</strong></td>
      <td><strong>Client ID</strong></td>
      <td><strong>Name</strong></td>
      <td><strong>Address</strong></td>
      <td><strong>Email</strong></td>
      <td><strong>Phone</strong></td>
      <td><strong>Balance</strong></td>
      <td><strong>Updated On</strong></td>
    </thead>
    <tbody>
      <?php
      foreach ($users as $user) {
        ?>
        <tr>
          <td>
            <a href="<?php echo base_url() ?>index.php/web/user/<?php echo $user['user_id']; ?>">
              #<?php echo $user['user_id']; ?>
            </a>
          </td>
          <td>
            <a href="<?php echo base_url() ?>index.php/web/client/<?php echo $user['client_id']; ?>">
              #<?php echo $user['client_id']; ?>
            </a>
          </td>
          <td>
            <?php echo $user['first_name']." ".$user['last_name']; ?>
          </td>
          <td>
            <?php echo $user['address_line_1']; ?>
          </td>
          <td>
            <?php echo $user['email']; ?>
          </td>
          <td>
            <?php echo $user['phone']; ?>
          </td>
          <td>
            <?php echo $user['wallet_balance']; ?>
          </td>
          <td>
            <?php echo $user['updated_on']; ?>
          </td>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</center>