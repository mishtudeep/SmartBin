<?php
include "base_view.php";
?>
<center>
    <table width="80%">
        <tr>
            <td><h2>Clients</h2></td>
            <td>
                <a href="<?php echo base_url() ?>index.php/web/add_client">Add Client</a>
            </td>
        </tr>
    </table>
    <table width="80%" border="1px">
        <thead>
            <td><strong>Client ID</strong></td>
            <td><strong>Name</strong></td>
            <td><strong>Address</strong></td>
            <td><strong>Email</strong></td>
            <td><strong>Phone</strong></td>
            <td><strong>Emergency Contact</strong></td>
            <td><strong>Updated On</strong></td>
        </thead>
        <tbody>
            <?php
            foreach($clients as $client) {
                ?>
                <tr>
                    <td>
                        <a href="<?php echo base_url()?>index.php/web/client/<?php echo $client['client_id']; ?>">
                            #<?php echo $client['client_id']; ?>
                        </a>
                    </td>
                    <td>
                        <?php echo $client['client_name']; ?>
                    </td>
                    <td>
                        <?php echo $client['address_line_1']; ?>
                    </td>
                    <td>
                        <?php echo $client['primary_email']; ?>
                    </td>
                    <td>
                        <?php echo $client['primary_phone']; ?>
                    </td>
                    <td>
                        <?php echo $client['emergency_contact']; ?>
                    </td>
                    <td>
                        <?php echo $client['updated_on']; ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
</center>