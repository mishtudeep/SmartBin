<?php
include "base_view.php";
?>

<center>
  <table width="80%">
    <tr>
      <td>
        <h2>Dumps</h2>
      </td>
    </tr>
  </table>
  <table width="80%" border="1px">
    <thead>
      <td><strong>Dump ID</strong></td>
      <td><strong>Bin ID</strong></td>
      <td><strong>User ID</strong></td>
      <td><strong>Starting Weight</strong></td>
      <td><strong>Ending Weight</strong></td>
      <td><strong>Weight</strong></td>
      <td><strong>Cost</strong></td>
      <td><strong>Start Time</strong></td>
      <td><strong>End Time</strong></td>
      <td><strong>Time</strong></td>
      <td><strong>Updated On</strong></td>
    </thead>
    <tbody>
      <?php
      foreach ($dumps as $dump) {
        ?>
        <tr>
          <td>
            <a href="<?php echo base_url() ?>index.php/web/dump/<?php echo $dump['dump_id']; ?>">
              #<?php echo $dump['dump_id']; ?>
            </a>
          </td>
          <td>
            <a href="<?php echo base_url() ?>index.php/web/bin/<?php echo $dump['bin_id']; ?>">
              #<?php echo $dump['bin_id']; ?>
            </a>
          </td>
          <td>
            <a href="<?php echo base_url() ?>index.php/web/user/<?php echo $dump['user_id']; ?>">
              #<?php echo $dump['user_id']; ?>
            </a>
          </td>
          <td>
            <?php echo $dump['starting_weight']; ?>Kg
          </td>
          <td>
            <?php echo $dump['ending_weight']; ?>Kg
          </td>
          <td>
            <?php echo $dump['weight']; ?>Kg
          </td>
          <td>
            $<?php echo $dump['cost']; ?>
          </td>
          <td>
            <?php echo $dump['start_time']; ?>
          </td>
          <td>
            <?php echo $dump['ending_time']; ?>
          </td>
          <td>
            <?php echo $dump['time_taken']; ?> Sec
          </td>
          <td>
            <?php echo $dump['updated_on']; ?>
          </td>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</center>