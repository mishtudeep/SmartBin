<center>
  <form action="<?php echo base_url() ?>index.php/web/login_api">
    <h2>BinBillings Web App</h2>
    <a href="<?php echo base_url() ?>index.php/web/client_login"> Client Login </a>
    <br>
    <br>
    <a href="<?php echo base_url() ?>index.php/web/admin_login"> Admin Login </a>
  </form>
</center>