<center>
  <form action="<?php echo base_url() ?>index.php/web/client_login_api" method="post">
    <h2>BinBillings Web App</h2>
    <h2>Client Login</h2>
    Email: <input type="text" name="email" value="client_admin@binbillings.com"/>
    Password: <input type="password" name="password"  value="client_admin"/>
    <input type="submit" value="Login" />
  </form>
</center>