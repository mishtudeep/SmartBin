<?php
include "base_view.php";
?>

<center>
    <table width="80%">
        <tr>
            <td>
                <h2>Bins</h2>
            </td>
            <td>
                <a href="<?php echo base_url() ?>index.php/web/add_bin">Add Bin</a>
            </td>
        </tr>
    </table>
    <table width="80%" border="1px">
        <thead>
            <td><strong>Bin ID</strong></td>
            <td><strong>Client ID</strong></td>
            <td><strong>Height</strong></td>
            <td><strong>Width</strong></td>
            <td><strong>Length</strong></td>
            <td><strong>Capacity</strong></td>
            <td><strong>Weight</strong></td>
            <td><strong>Name</strong></td>
            <td><strong>Address</strong></td>
            <td><strong>Latitude</strong></td>
            <td><strong>Longitude</strong></td>
            <td><strong>Updated On</strong></td>
        </thead>
        <tbody>
            <?php
            foreach ($bins as $bin) {
                ?>
                <tr>
                    <td>
                        <a href="<?php echo base_url() ?>index.php/web/bin/<?php echo $bin['bin_id']; ?>">
                            #<?php echo $bin['bin_id']; ?>
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo base_url() ?>index.php/web/client/<?php echo $bin['client_id']; ?>">
                            #<?php echo $bin['client_id']; ?>
                        </a>
                    </td>
                    <td>
                        <?php echo $bin['height']; ?>
                    </td>
                    <td>
                        <?php echo $bin['width']; ?>
                    </td>
                    <td>
                        <?php echo $bin['length']; ?>
                    </td>
                    <td>
                        <?php echo $bin['capacity']; ?>
                    </td>
                    <td>
                        <?php echo $bin['weight']; ?>
                    </td>
                    <td>
                        <?php echo $bin['house_name']; ?>
                    </td>
                    <td>
                        <?php echo $bin['address_line_1']; ?>
                    </td>
                    <td>
                        <?php echo $bin['latitude']; ?>
                    </td>
                    <td>
                        <?php echo $bin['longitude']; ?>
                    </td>
                    <td>
                        <?php echo $bin['updated_on']; ?>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</center>