<center>
    <table width="80%">
        <tr>
        <h2>BinBillings Web App</h2>
        </tr>
        <tr>
        <td><a href="<?php echo base_url() ?>index.php/web/home">Home</a></td>
        <?php 
        if ($role == 'admin') {
        ?>
            <td><a href="<?php echo base_url() ?>index.php/web/clients">Clients</a></td>
        <?php 
        } 
        ?>
        <td><a href="<?php echo base_url() ?>index.php/web/bins">Bins</a></td>
        <td><a href="<?php echo base_url() ?>index.php/web/users">Users</a></td>
        <td><a href="<?php echo base_url() ?>index.php/web/dumps">Dumps</a></td>
        <td><a href="<?php echo base_url() ?>index.php/web/logout">Logout</a></td>
        </tr>
    </table>
    <br><br>
</center>