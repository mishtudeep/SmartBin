<?php
include "base_view.php";
?>

<center>
  <?php
  echo $bin['name'];
  ?>
  <br><br>
</center>