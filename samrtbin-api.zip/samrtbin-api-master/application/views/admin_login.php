<center>
  <form action="<?php echo base_url() ?>index.php/web/admin_login_api" method="post">
    <h2>BinBillings Web App</h2>
    <h2>Admin Login</h2>
    Email: <input type="text" name="email" value="admin@binbillings.com"/>
    Password: <input type="password" name="password"  value="admin1234"/>
    <input type="submit" value="Login" />
  </form>
</center>