import paho.mqtt.client as mqtt
import json
import requests

server_ip = "3.16.200.142"
base_url = "http://"+server_ip+"/smartbin-api/index.php/v1/api/"

# The callback for when the client receives a CONNACK response from the server.


def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe("open/#")
    client.subscribe("ACK/#")
    client.subscribe("ping/#")

# The callback for when a PUBLISH message is received from the server.


def on_message(client, userdata, msg):
    print(msg.topic + " ==> " + str(msg.payload))
    
    value = json.loads(msg.payload)
    print("value: " + str(value))
    
    msg_topic_parts = msg.topic.split('/')
    print("msg_topic_parts: " + str(msg_topic_parts))

    msg_topic_action = msg_topic_parts[0]

    print("msg_topic_action: " + msg_topic_action)

    if (msg_topic_action == 'open') :
      action = value['Action']
      data = value['ID']
      
      print("open ", action, data)

    elif (msg_topic_action == 'ACK'):
      dump_id = value['ID']
      weight = value['Weight']
      action = value['Action']

      url = base_url + "ack_dump"
      response = requests.post(url=url, data=value)
      print("response: " + response.text)
      print("ACK val: " + str(dump_id) + ": " + str(weight) + " : " + str(action))

    elif (msg_topic_action == 'ping'):
      bin_id = value['ID']
      gas_val = value['Gas']
      temp_val = value['Temperature']
      humidity_val = value['Humidity']

      url = base_url + "hearbeat_dump"
      response = requests.post(url=url, data=value)
      print("response: " + response.text)

      print("heartBeat val: " + str(bin_id) + ": " + str(gas_val) + ": " + str(temp_val) + ": " +str(humidity_val))


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("localhost", 1883, 60)

# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.loop_forever()
