import os
import json
from time import sleep

server_ip = "3.17.5.117"

# hbeat_payload = json.dumps({'ID': 1, 'Gas': 650, 'Temperature': 45, 'Humidity': 77}).replace('"', '\\"')
# command = "mosquitto_pub -h "+server_ip+" -t ping/1 -m \"" + hbeat_payload + "\""
# print(command)
# os.system(command)
# sleep(1)


open_payload = json.dumps({'ID': 1, 'Action': "1"}).replace('"', '\\"')
command = "mosquitto_pub -h "+server_ip+" -t open/1 -m \"" + open_payload + "\""
print(command)
os.system(command)
sleep(1)


# ack_payload = json.dumps({'ID': 1, 'Weight': 50, 'Action': 'open'}).replace('"', '\\"')
# command = "mosquitto_pub -h "+server_ip+" -t ACK/1 -m \"" + ack_payload + "\""
# print(command)
# os.system(command)
# sleep(1)


# close_payload = json.dumps({'ID': 1, 'Action': "0"}).replace('"', '\\"')
# command = "mosquitto_pub -h "+server_ip+" -t open/1 -m \"" + close_payload + "\""
# print(command)
# os.system(command)
# sleep(1)

# ack_payload = json.dumps({'ID': 1, 'Weight': 70, 'Action': 'close'}).replace('"', '\\"')
# command = "mosquitto_pub -h "+server_ip+" -t ACK/1 -m \"" + ack_payload + "\""
# print(command)
# os.system(command)
