-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Sep 22, 2019 at 08:40 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `wastage`
--

-- --------------------------------------------------------

--
-- Table structure for table `bin_client`
--

CREATE TABLE `bin_client` (
  `client_id` bigint(20) NOT NULL,
  `client_name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_1` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_2` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `primary_email` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `primary_phone` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_contact` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `logo_image` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bin_client`
--

INSERT INTO `bin_client` (`client_id`, `client_name`, `address_line_1`, `address_line_2`, `primary_email`, `primary_phone`, `emergency_contact`, `logo_image`, `updated_on`) VALUES
(1, 'Dummy Client 1', 'Dummy client address 1', 'Dummy client address 2', 'client@binbillings.com', '9876543210', '9876543210', '', '2019-09-18 15:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `bin_client_admin`
--

CREATE TABLE `bin_client_admin` (
  `admin_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `first_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `profile_pic` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bin_client_admin`
--

INSERT INTO `bin_client_admin` (`admin_id`, `client_id`, `first_name`, `last_name`, `email`, `phone`, `profile_pic`, `password`, `updated_on`) VALUES
(1, 1, 'Client', 'Admin', 'client_admin@binbillings.com', '9876543210', NULL, 'client_admin', '2019-09-18 15:46:03');

-- --------------------------------------------------------

--
-- Table structure for table `bin_dumps`
--

CREATE TABLE `bin_dumps` (
  `dump_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `bin_id` bigint(20) NOT NULL,
  `starting_weight` float DEFAULT NULL,
  `ending_weight` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `ending_time` datetime DEFAULT NULL,
  `time_taken` float DEFAULT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bin_dumps`
--

INSERT INTO `bin_dumps` (`dump_id`, `user_id`, `bin_id`, `starting_weight`, `ending_weight`, `weight`, `cost`, `start_time`, `ending_time`, `time_taken`, `updated_on`) VALUES
(1, 1, 1, 0, 10, 10, 10, '2019-09-23 01:49:30', '2019-09-23 01:53:33', 123, '2019-09-22 20:23:33');

-- --------------------------------------------------------

--
-- Table structure for table `bin_dump_transaction_map`
--

CREATE TABLE `bin_dump_transaction_map` (
  `dump_transaction_id` bigint(20) NOT NULL,
  `dump_id` bigint(20) NOT NULL,
  `transaction_id` bigint(20) NOT NULL,
  `update_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bin_dustbin`
--

CREATE TABLE `bin_dustbin` (
  `bin_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `height` float NOT NULL,
  `width` float NOT NULL,
  `length` float NOT NULL,
  `capacity` float NOT NULL,
  `weight` float NOT NULL DEFAULT '0',
  `house_name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_1` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_2` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bin_dustbin`
--

INSERT INTO `bin_dustbin` (`bin_id`, `client_id`, `height`, `width`, `length`, `capacity`, `weight`, `house_name`, `address_line_1`, `address_line_2`, `latitude`, `longitude`, `updated_on`) VALUES
(1, 1, 30, 20, 20, 50, 0, 'Dummy Dump House', 'Dummy bin address 1', 'Dummy bin address 2', 22.572645, 88.363892, '2019-09-18 17:15:38');

-- --------------------------------------------------------

--
-- Table structure for table `bin_dustbin_stats`
--

CREATE TABLE `bin_dustbin_stats` (
  `stats_id` bigint(20) NOT NULL,
  `bin_id` bigint(20) NOT NULL,
  `temperature` float NOT NULL,
  `humidity` float NOT NULL,
  `weight` float NOT NULL,
  `gas_concentration` float NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bin_transaction`
--

CREATE TABLE `bin_transaction` (
  `transaction_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `transaction_token` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `amount` float NOT NULL,
  `status` enum('success','failed') COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('debit','credit') COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bin_user`
--

CREATE TABLE `bin_user` (
  `user_id` bigint(20) NOT NULL COMMENT ' ',
  `client_id` bigint(20) NOT NULL,
  `first_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_1` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `address_line_2` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `profile_pic` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `referral_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `wallet_balance` float NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bin_user`
--

INSERT INTO `bin_user` (`user_id`, `client_id`, `first_name`, `last_name`, `address_line_1`, `address_line_2`, `email`, `phone`, `profile_pic`, `referral_code`, `password`, `wallet_balance`, `updated_on`) VALUES
(1, 1, 'Dummy', 'User', 'Dummy user address 1', 'Dummy user address 2', 'dummy_user@binbillings.com', '9876543210', 'pic.jpg', 'code#1', '11111111', 0, '2019-09-18 16:15:24');

-- --------------------------------------------------------

--
-- Table structure for table `bin_user_card`
--

CREATE TABLE `bin_user_card` (
  `card_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `card_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `expiry_month` int(11) NOT NULL,
  `expiry_year` int(11) NOT NULL,
  `holder_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive','blocked','removed') COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bin_client`
--
ALTER TABLE `bin_client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `bin_client_admin`
--
ALTER TABLE `bin_client_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bin_dumps`
--
ALTER TABLE `bin_dumps`
  ADD PRIMARY KEY (`dump_id`);

--
-- Indexes for table `bin_dump_transaction_map`
--
ALTER TABLE `bin_dump_transaction_map`
  ADD PRIMARY KEY (`dump_transaction_id`);

--
-- Indexes for table `bin_dustbin`
--
ALTER TABLE `bin_dustbin`
  ADD PRIMARY KEY (`bin_id`);

--
-- Indexes for table `bin_dustbin_stats`
--
ALTER TABLE `bin_dustbin_stats`
  ADD PRIMARY KEY (`stats_id`);

--
-- Indexes for table `bin_transaction`
--
ALTER TABLE `bin_transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `bin_user`
--
ALTER TABLE `bin_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `bin_user_card`
--
ALTER TABLE `bin_user_card`
  ADD PRIMARY KEY (`card_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bin_client`
--
ALTER TABLE `bin_client`
  MODIFY `client_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bin_client_admin`
--
ALTER TABLE `bin_client_admin`
  MODIFY `admin_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bin_dumps`
--
ALTER TABLE `bin_dumps`
  MODIFY `dump_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bin_dump_transaction_map`
--
ALTER TABLE `bin_dump_transaction_map`
  MODIFY `dump_transaction_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bin_dustbin`
--
ALTER TABLE `bin_dustbin`
  MODIFY `bin_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bin_dustbin_stats`
--
ALTER TABLE `bin_dustbin_stats`
  MODIFY `stats_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bin_transaction`
--
ALTER TABLE `bin_transaction`
  MODIFY `transaction_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bin_user`
--
ALTER TABLE `bin_user`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT ' ', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bin_user_card`
--
ALTER TABLE `bin_user_card`
  MODIFY `card_id` bigint(20) NOT NULL AUTO_INCREMENT;
